package movie_project;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Calendar;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

import movie_db.DateSelectionDao;
import movie_db.MovieDao;

public class DateSelection extends JFrame implements ActionListener {
	Calendar cal = Calendar.getInstance();
	MovieDao mdo = null;
	public MovieDetail md = null;
	public DateSelectionDao dsDao = null;
	public SeatSelection ss = null;
	String seat_num;
	int week;
	public String cal_date = null;
	public String time_code = null;
	
	JPanel jp_north = new JPanel();	//추가.
		JButton jbtn_lastmon = new JButton("이전 달"); 
		JButton jbtn_nextmon = new JButton("다음 달"); 

	JPanel jp_main = new JPanel();
		JPanel jp_north2 = new JPanel(new GridLayout(0, 1, 0, 0));
			JLabel jlb_mon = new JLabel(); // 상단 년, 월
			JPanel jp_title = new JPanel(new GridLayout(1, 7));
				JButton jbtn_title[] = new JButton[7]; // 월~금 버튼
		JPanel jp_center = new JPanel(new GridLayout(0, 7)); 
			JButton jbtn_day[] = new JButton[31]; // 날짜
			
	JPanel jp_bottom = new JPanel(new BorderLayout(10,10));
		JPanel jp_south = new JPanel();	
			JPanel jp_south2 = new JPanel(new GridLayout(0, 3));
				JLabel jlb_time[] = new JLabel[3];
				JButton jbtn_time[] = new JButton[3];
		JPanel jp_bottom3 = new JPanel();
				JButton jbtn_pre = new JButton("이전");
				JButton jbtn_next = new JButton("다음");
	
	
	String dayOfWeek[] = {"Mon", "Tue", "Wen", "Thu", "Fri", "Sat", "Sun"}; 
	int year = cal.get(Calendar.YEAR); 
	int month = cal.get(Calendar.MONTH)+1;
	
	public DateSelection(MovieDetail md) {
		this.md = md;
		initDisplay();				
	}

	public void initDisplay() {	
		this.setLayout(new BorderLayout(10, 10));
		
		
		
		
		jlb_mon.setHorizontalAlignment(SwingConstants.CENTER);	//월(라벨)
		for(int i=0; i<7; i++) {								
			jbtn_title[i] = new JButton(dayOfWeek[i]);			
			jbtn_title[i].setBackground(Color.LIGHT_GRAY);		
			jbtn_title[i].setPreferredSize(new Dimension(60, 30));	
			jp_title.add(jbtn_title[i]);						
		}														
		
		int dayOfMonth = cal.get(Calendar.DAY_OF_MONTH);	 
		makeCal(month);									
		jbtn_pre.addActionListener(this);						
		jbtn_next.addActionListener(this);						
		jp_north2.add(jlb_mon);										
		jp_north2.add(jp_title);	
		jp_south.add(jp_south2);
		jp_south2.setVisible(false);
		
		jp_main.add(jp_north2);	
		jp_main.add(jp_center);				
		jp_bottom.add("Center", jp_south);
		jp_bottom.add("South", jp_bottom3);
		
		makersv();
		
		jp_bottom3.add(jbtn_pre);	
		jp_bottom3.add(jbtn_next);
		
		jbtn_lastmon.setBackground(Color.WHITE);
		jbtn_nextmon.setBackground(Color.WHITE);
		jbtn_pre.setBackground(Color.WHITE);
		jbtn_next.setBackground(Color.WHITE);
		
//		jp_center.setBackground(Color.WHITE);
//		jp_main.setBackground(Color.WHITE);
//		jp_north.setBackground(Color.WHITE);
//		jp_north2.setBackground(Color.WHITE);
//		jp_bottom.setBackground(Color.WHITE);
//		jp_bottom3.setBackground(Color.WHITE);
//		jp_south.setBackground(Color.WHITE);
//		jp_south2.setBackground(Color.WHITE);
//		jp_title.setBackground(Color.WHITE);
	
		this.add("North",jp_north);				
		this.add("Center",jp_main);						
		this.add("South", jp_bottom);
		
		jbtn_lastmon.addActionListener(new ActionListener() { 	
			public void actionPerformed(ActionEvent e) {	
				jp_south2.setVisible(false);
				makeCal(--month);						
			}											
		});													
		
		jp_north.add(jbtn_lastmon);							
		jp_north.add(jbtn_lastmon);							
		jbtn_nextmon.addActionListener(new ActionListener() { 		
			public void actionPerformed(ActionEvent e) {	
				jp_south2.setVisible(false);
				makeCal(++month);								
			}
		});
		
		jp_north.add(jbtn_nextmon);			
		this.setSize(500, 470);		
		this.setLocationRelativeTo(null);
		this.setResizable(false);							
		this.setVisible(true);
	}
	
	public void makersv() { //하단 상영관라벨, 상영시간 버튼생성하는 함수
		for(int i=0; i<3; i++) {
			jlb_time[i] = new JLabel("--");
			jlb_time[i].setHorizontalAlignment(JLabel.CENTER);
			jp_south2.add(jlb_time[i]);
			jlb_time[i].setPreferredSize(new Dimension(80, 25));
			jlb_time[i].setOpaque(true);
			jlb_time[i].setBackground(Color.WHITE);
			jlb_time[i].setEnabled(false);
		}
		for(int i=0; i<3; i++) {
			jbtn_time[i] = new JButton("--");
			jp_south2.add(jbtn_time[i]);
			jbtn_time[i].setPreferredSize(new Dimension(80, 25));
			jbtn_time[i].setBackground(Color.WHITE);
			jbtn_time[i].addActionListener(this);
			jbtn_time[i].setEnabled(true);
		}
	}
	
	public void makeCal(int month){ //이전, 다음달 달력만드는함수
		jp_center.removeAll();
		cal.set(year, month-1, 1);		
		
		int std=0;												
		week = cal.get(Calendar.DAY_OF_WEEK);
		if(week == 1) {
			week = 8;										
		}
		for(int i=1; i<week-1; i++) {						
			JButton jbtn_null = new JButton("");				
			jbtn_null.setBackground(Color.WHITE);
			jbtn_null.setPreferredSize(new Dimension(60, 30));
			jbtn_null.addActionListener(this);
			jp_center.add(jbtn_null);
			std++;
			if(std==7) std=0;
		}
		for(int i=0; i<cal.getActualMaximum(cal.DAY_OF_MONTH); i++) {
			jbtn_day[i] = new JButton(String.valueOf(i+1));
			jbtn_day[i].setBackground(Color.WHITE);
			jbtn_day[i].addActionListener(this);
			jp_center.add(jbtn_day[i]);
			std++;
			if(std==7) std=0;
		}
		for(int i=std; i<7; i++) {
			JButton jbtn_null = new JButton("");
			jbtn_null.setBackground(Color.WHITE);
			jbtn_null.setPreferredSize(new Dimension(60, 30));
			jp_center.add(jbtn_null);
		}
		jlb_mon.setText(cal.get(Calendar.YEAR)+"년 "+(cal.get(Calendar.MONTH)+1)+" 월");									
		this.setVisible(true);									
	}

	public void setTime() {
		dsDao = new DateSelectionDao(this);
		dsDao.theater(); // DB에서 상영관 코드 받아옴.
		dsDao.time(dsDao.theater()); //// DB에서 상영관 시간 받아옴
	}
	
	@Override
	public void actionPerformed(ActionEvent e) { 
		Object obj = e.getSource();
		for(int i=0; i<cal.getActualMaximum(cal.DAY_OF_MONTH); i++) {
			if(obj == jbtn_day[i]) { //날짜버튼 클릭시
				if(jbtn_day[i].getBackground() == Color.GRAY) { //선택되있는 날짜 초기화
					jbtn_day[i].setBackground(Color.WHITE);
					jp_south2.setVisible(false);
					return;
				}
				else { //선택되있지 않은 날짜를 선택할 때
					for(int j=0; j<cal.getActualMaximum(cal.DAY_OF_MONTH); j++) {
						jbtn_day[j].setBackground(Color.WHITE); 
					}
					jbtn_day[i].setBackground(Color.GRAY); 
					setTime();
					jlb_time[0].setText(dsDao.theater);
					jbtn_time[0].setText(dsDao.time.get(0));
					jbtn_time[1].setText(dsDao.time.get(1));
					jbtn_time[2].setText("-");
					jbtn_time[2].setEnabled(false);
					jp_south2.setVisible(true);
				}
			}
		}
		
		for(int i=0; i<2; i++) {
			if(obj == jbtn_time[i]) {//시간 선택시
				if(jbtn_time[i].getBackground() == Color.GRAY) {
				   jbtn_time[i].setBackground(Color.WHITE);
				   return;
				}
				else {
					for(int j=0; j<2; j++) {
						jbtn_time[j].setBackground(Color.WHITE);
					}
					jbtn_time[i].setBackground(Color.GRAY);
				}
			}
		}//end of for
		
		if(obj == jbtn_next) { //다음 버튼
			int change = 0;
			int change2 = 0;
			String time = null;
			
			for(int i=0; i<cal.getActualMaximum(cal.DAY_OF_MONTH); i++) {
				if(jbtn_day[i].getBackground() == Color.GRAY) {  //선택된 날짜가 있을 때
					change = 1;
				}
			}
			
			for(int i=0; i<2; i++) {
				if(jbtn_time[i].getBackground() == Color.GRAY) {  //선택된 시간이 있을 때
					change2 = 1;
				}
			}
			
			if(change == 0) { //선택된 날짜가 없을 때
				System.out.println("날짜를 선택하세요");
				return; 
			}
			else if(change2 == 0) { //선택된 시간이 없을 때
				System.out.println("시간을 선택하세요");
				return; 
			}
			
			for(int i=0; i<2; i++) { //선택된 시간이 있을 때, time(String)변수에 버튼 텍스트값 읽음
				if(jbtn_time[i].getBackground() == Color.GRAY) {
					time = jbtn_time[i].getText();
				}
			}
			
			time_code = dsDao.timeCode(time, dsDao.theater);
			
			//날짜 전역변수 cal_date에 초기화
			String calendar_date = null;
			for(int i=0; i<cal.getActualMaximum(cal.DAY_OF_MONTH); i++) {
				if(jbtn_day[i].getBackground() == Color.GRAY) { 
					calendar_date = jbtn_day[i].getText();
				}
			}
			String smonth = null;
			
			if(month <10) {
				smonth = "0" + month;
			} else {
				smonth = "" + month;
			}
			
			if(Integer.parseInt(calendar_date)<10) {
				calendar_date = "0" + calendar_date;
			}
			
			
			cal_date = year + smonth + calendar_date;
			ss = new SeatSelection(this);
			this.dispose();
		}
		
		else if(obj == jbtn_pre) { //이전 버튼
			md = new MovieDetail(this.md.ms);
			this.dispose();
		}
	}
}







