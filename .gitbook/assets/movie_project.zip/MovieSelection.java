package movie_project;
//정보 더 입력하고싶으면 버튼 누를때마다 새로 창여는 cardrayout   

import java.awt.Color;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JPanel;


public class MovieSelection extends JFrame implements ActionListener {
	// 선언부
	String imgPath = "src\\movie_project\\";
	JPanel jp_center = new JPanel();
	
	JButton jbtn[] = new JButton[8];
	JButton jbtn_pre = new JButton("이전");
	JLabel jlb_cgv = new JLabel(new ImageIcon(imgPath + "팝콘2.png"));
	
	MovieDetail md = null;
	public MovieMainView mmv = null;
	public Icon icon;
	public String mv_code;
	String mvtext[] = new String[jbtn.length];

	public MovieSelection(MovieMainView mmv) {
		this.mmv = mmv;
		initDisplay();
	}

	// 화면처리부
	public void initDisplay() {
		jp_center.setLayout(null);
		jp_center.setBackground(Color.WHITE);
		jlb_cgv.setBounds(700, 600, 200, 200);
		jp_center.add(jlb_cgv);
		
		jbtn[0] = new JButton(new ImageIcon(imgPath + "다만악에서구하소서.png"));
		jbtn[1] = new JButton(new ImageIcon(imgPath + "나의소녀시대.png"));
		jbtn[2] = new JButton(new ImageIcon(imgPath + "오케이마담.png"));
		jbtn[3] = new JButton(new ImageIcon(imgPath + "짱구.png"));
		jbtn[4] = new JButton(new ImageIcon(imgPath + "남매의여름밤.png"));
		jbtn[5] = new JButton(new ImageIcon(imgPath + "강철비2.png"));
		jbtn[6] = new JButton(new ImageIcon(imgPath + "반교디텐션.png"));
		jbtn[7] = new JButton(new ImageIcon(imgPath + "시크릿가든.png"));
		
		for(int i=0; i<mvtext.length; i++)
			mvtext[i] = "mv_" + (i+1);
		
		jbtn_pre.addActionListener(this);
		for(int i=0; i<jbtn.length; i++) 
			jbtn[i].addActionListener(this);
		jbtn_pre.setBounds(400,700,100,30);
		jp_center.add(jbtn_pre);

		jbtn[0].setBounds(20, 20, 200, 300);
		jbtn[1].setBounds(240, 20, 200, 300);
		jbtn[2].setBounds(460, 20, 200, 300);
		jbtn[3].setBounds(680, 20, 200, 300);
		jbtn[4].setBounds(20, 360, 200, 300);
		jbtn[5].setBounds(240, 360, 200, 300);
		jbtn[6].setBounds(460, 360, 200, 300);
		jbtn[7].setBounds(680, 360, 200, 300);
		
		for(int i=0; i<jbtn.length; i++)
			jp_center.add(jbtn[i]);
		this.add(jp_center);
		this.setSize(920, 790);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Object obj = e.getSource();
		
		for(int i=0; i<jbtn.length; i++) {
			if(obj == jbtn[i]) { //영화 버튼 클릭
				icon = jbtn[i].getIcon();
				mv_code = mvtext[i];
				md = new MovieDetail(this);
				this.dispose();
			}
		}
		
		if(obj == jbtn_pre) { //이전 버튼
			mmv = new MovieMainView(mmv.lf);
			this.dispose();
		}
	}
}