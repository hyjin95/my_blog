package movie_project;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextField;

import movie_db.MemberDAO;
import movie_db.MovieDao;
import movie_db.ZipCodeSearch;

public class MemberShip extends JDialog implements ActionListener, MouseListener{
	//선언부
	ZipCodeSearch zcs = null;
	MemberDAO md = new MemberDAO(this);
	
	String imgPath = "src\\movie_project3\\";	
	JLabel jlb_img = new JLabel(new ImageIcon(imgPath + "팝콘2.png"));
	
	JPanel  jp_south = new JPanel();
	JButton jbtn_ins = new JButton("등록");
	JButton jbtn_close = new JButton("닫기");
	
	JPanel     jp_center = new JPanel();
	JLabel     jlb_id    = new JLabel("아이디 : ");
	JTextField jtf_id    = new JTextField(10);
	JButton    jbtn_find = new JButton("중복검사");
	
	JLabel     jlb_pw  = new JLabel("비밀번호 : ");
	JLabel     jlb_pw2 = new JLabel("비밀번호 확인 : ");
	JPasswordField jpf_pw = new JPasswordField(20);
	JPasswordField jpf_pw2 = new JPasswordField(20);
	JButton    jbtn_pw = new JButton("확인");
	
	JLabel     jlb_name = new JLabel("이름 : ");
	JTextField jtf_name = new JTextField(20);
	JLabel     jlb_nick = new JLabel("닉네임 : ");
	JTextField jtf_nick = new JTextField(30);
	JLabel     jlb_gender = new JLabel("성별 : ");
	String[] genderList = {"남자", "여자"};
	JComboBox jcb_gender = new JComboBox(genderList);//고정된 상수값이므로 벡터사용하지 않는다.
	
	JLabel     jlb_zdo = new JLabel("우편번호 : ");
	JLabel     jlb_zdo2 = new JLabel("주소 : ");
	JLabel     jlb_zdo3 = new JLabel("상세주소 : ");
	
	JLabel     jlb_tel = new JLabel("연락처 : ");
	JTextField jtf_tel = new JTextField(30);
	
	public JTextField jtf_zdo = new JTextField(6);
	public JTextField jtf_zdo2 = new JTextField(100);
	public JTextField jtf_zdo3 = new JTextField(100);
	JButton    jbtn_zdo = new JButton("우편번호조회");
	int id;
	int pw;
	String privacy[] = new String[8];
	int    privacy_no = 0;
	
	//생성자
	public MemberShip() {
		initDisplay();
	}
	
	//화면처리부
	public void initDisplay() {
		jp_center.setLayout(null);
		jp_center.setBackground(Color.WHITE);
		jp_south.setBackground(Color.WHITE);
		
		jbtn_ins.setBackground(Color.LIGHT_GRAY);
		jbtn_find.setBackground(Color.LIGHT_GRAY);
		jbtn_pw.setBackground(Color.LIGHT_GRAY);
		jbtn_zdo.setBackground(Color.LIGHT_GRAY);
		jbtn_close.setBackground(Color.LIGHT_GRAY);
		
		jp_center.add(jlb_img);
		jlb_img.setBounds(70, 10, 200, 80);
		
		jlb_id.setBounds(45, 120, 100, 20);//라벨이 입력창보다 왼쪽(앞)에 위치해야한다.
		jtf_id.setBounds(95, 120, 100, 20);
		jbtn_find.setBounds(200, 120, 90, 19);
		
		jp_center.add(jlb_id);
		jp_center.add(jtf_id);
		jp_center.add(jbtn_find);
		
		jlb_pw.setBounds(32, 150, 100, 20);
		jlb_pw2.setBounds(3, 170, 100, 20);
		jpf_pw.setBounds(95, 150, 100, 20);
		jpf_pw2.setBounds(95, 170, 100, 20);
		jbtn_pw.setBounds(200, 170, 60, 19);
		jp_center.add(jlb_pw);
		jp_center.add(jlb_pw2);
		jp_center.add(jpf_pw);
		jp_center.add(jpf_pw2);
		jp_center.add(jbtn_pw);
		
		jlb_name.setBounds(58, 200, 100, 20);
		jtf_name.setBounds(95, 200, 100, 20);
		jp_center.add(jlb_name);
		jp_center.add(jtf_name);
		jlb_nick.setBounds(45, 220, 100, 20);
		jtf_nick.setBounds(95, 220, 100, 20);
		jp_center.add(jlb_nick);
		jp_center.add(jtf_nick);
		jlb_gender.setBounds(200, 200, 100, 20);
		jcb_gender.setBounds(240, 200, 58, 19);
		jcb_gender.setFont(new Font("굴림",1,12));
		jp_center.add(jlb_gender);
		jp_center.add(jcb_gender);
		
		jlb_zdo.setBounds(32, 250, 100, 20);
		jlb_zdo2.setBounds(58, 280, 100, 20);
		jlb_zdo3.setBounds(32, 300, 100, 20);
		jtf_zdo.setBounds(95, 250, 100, 20);
		jtf_zdo2.setBounds(95, 280, 220, 20);
		jtf_zdo3.setBounds(95, 300, 220, 20);
		jbtn_zdo.setBounds(200, 250, 114, 19);
		
		jlb_tel.setBounds(45, 330, 100, 20);
		jtf_tel.setBounds(95, 330, 220, 20);
		jp_center.add(jlb_tel);
		jp_center.add(jtf_tel);
		jtf_tel.setText("-제외한 숫자만 입력하세요.");
		
		jp_center.add(jlb_zdo);
		jp_center.add(jlb_zdo2);
		jp_center.add(jlb_zdo3);
		jp_center.add(jtf_zdo);
		jp_center.add(jtf_zdo2);
		jp_center.add(jtf_zdo3);
		jp_center.add(jbtn_zdo);
		
		jtf_tel.addMouseListener(this);
		jbtn_find.addActionListener(this);
		jbtn_zdo.addActionListener(this);
		jbtn_pw.addActionListener(this);
		jbtn_close.addActionListener(this);
		jbtn_ins.addActionListener(this);
		
		jp_south.setLayout(new FlowLayout(FlowLayout.RIGHT));
		jp_south.add(jbtn_ins);
		jp_south.add(jbtn_close);
		
		this.add("Center", jp_center);
		this.add("South", jp_south);
		this.setTitle("회원가입");
		this.setSize(350, 450);
		this.setVisible(true);
	}
	
	public static void main(String[] args) {
		new MemberShip();		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Object obj = e.getSource();
		String pw = String.copyValueOf(jpf_pw.getPassword());
		String pw2 = String.copyValueOf(jpf_pw2.getPassword());
		
		if(obj == jbtn_close) {
			this.dispose();
		}
		else if(obj == jbtn_ins) {
			if("".equals(jtf_id.getText())) {
				JOptionPane.showMessageDialog(this, "아이디를 입력하세요."
											   , "INFO"
											   , JOptionPane.INFORMATION_MESSAGE);
			}
			else if("".equals(pw)) {
				JOptionPane.showMessageDialog(this, "비밀번호를 입력하세요."
						   , "INFO"
						   , JOptionPane.INFORMATION_MESSAGE);
		    }
			else if("".equals(pw2)) {
				JOptionPane.showMessageDialog(this, "비밀번호를 입력하세요."
						   , "INFO"
						   , JOptionPane.INFORMATION_MESSAGE);
		    }
			else if("".equals(jtf_name.getText())) {
				JOptionPane.showMessageDialog(this, "이름을 입력하세요."
						   , "INFO"
						   , JOptionPane.INFORMATION_MESSAGE);
		    }
			else if("".equals(jtf_nick.getText())) {
				JOptionPane.showMessageDialog(this, "닉네임을 입력하세요."
						   , "INFO"
						   , JOptionPane.INFORMATION_MESSAGE);
		    }
			else if("".equals(jtf_zdo.getText())) {
				JOptionPane.showMessageDialog(this, "우편번호를 입력하세요."
						   , "INFO"
						   , JOptionPane.INFORMATION_MESSAGE);
		    }
			else if("".equals(jtf_zdo2.getText())) {
				JOptionPane.showMessageDialog(this, "주소를 입력하세요."
						   , "INFO"
						   , JOptionPane.INFORMATION_MESSAGE);
		    }
			else if("".equals(jtf_zdo3.getText())) {
				JOptionPane.showMessageDialog(this, "상세주소를 입력하세요."
						   , "INFO"
						   , JOptionPane.INFORMATION_MESSAGE);
		    }
			else if("".equals(jtf_tel.getText())) {
				JOptionPane.showMessageDialog(this, "연락처를 입력하세요."
						, "INFO"
						, JOptionPane.INFORMATION_MESSAGE);
			}
			else if(id == 0) {
				JOptionPane.showMessageDialog(this, "아이디 중복검사를 해주세요."
						   , "INFO"
						   , JOptionPane.INFORMATION_MESSAGE);
			}
			else if(pw == null) {
				JOptionPane.showMessageDialog(this, "패스워드 중복검사를 해주세요."
						   , "INFO"
						   , JOptionPane.INFORMATION_MESSAGE);
			}
			else {
				privacy[0] = jtf_id.getText();//id
				privacy[1] = String.copyValueOf(jpf_pw.getPassword());;//pw
				privacy[2] = jtf_tel.getText();//연락처
				privacy[3] = jtf_name.getText();//이름
				privacy[4] = jtf_nick.getText();//닉네임
				privacy[5] = jcb_gender.getSelectedItem().toString(); //성별
				privacy[6] = jtf_zdo3.getText();//상세주소
				privacy[7] = jtf_zdo2.getText();//주소
				privacy_no = Integer.parseInt(jtf_zdo.getText());//우편번호
				md.uid_no(privacy, privacy_no);
				//System.out.println(md.num);
				md.setRegister(privacy);
			}
		}
		
		else if(obj == jbtn_pw) {
			if(!pw.equals(pw2)&&!(pw.length()==0 || pw2.length()==0)) {
				JOptionPane.showMessageDialog(this, "비밀번호가 다릅니다. 확인해주세요."
						, "INFO"
						, JOptionPane.INFORMATION_MESSAGE);
				this.pw = 1;
			}
			
			else if(pw.length()==0 || pw2.length()==0) {
				JOptionPane.showMessageDialog(this, "비밀번호가 입력되지 않았습니다."
						, "INFO"
						, JOptionPane.INFORMATION_MESSAGE);
				this.pw = 0;
			}
			else {
				JOptionPane.showMessageDialog(this, "확인되었습니다."
						, "INFO"
						, JOptionPane.INFORMATION_MESSAGE);
				this.pw = 1;
			}
		}
		
		else if(obj == jbtn_zdo) {
			zcs = new ZipCodeSearch(this);
		}
		
		else if(obj == jbtn_find) {
			md.getMemID(jtf_id.getText());
			
			if(jtf_id.getText().equals("")) {
				JOptionPane.showMessageDialog(this, "아이디를 입력하세요."
						, "INFO"
						, JOptionPane.INFORMATION_MESSAGE);
				id = 0;
			}
			else if(md.result ==0 ) {
				JOptionPane.showMessageDialog(this, "사용가능한 아이디입니다."
						, "INFO"
						, JOptionPane.INFORMATION_MESSAGE);
				id = 1;
			}
			else if(md.result == 1) {
				JOptionPane.showMessageDialog(this, "이미 사용중인 아이디입니다."
						, "INFO"
						, JOptionPane.INFORMATION_MESSAGE);
				id = 0;
			}
		}
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		if(e.getSource() == jtf_tel) {
			jtf_tel.setText("");	
		}	
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
}
