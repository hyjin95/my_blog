package movie_project;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

import movie_db.MovieConfirmSeatDao;

public class MovieConfirmSeat extends JFrame implements ActionListener {
	String data[][] = new String[0][2];
	String cols[] = {"상영관", "좌석번호"};
	public DefaultTableModel dtm_mv = new DefaultTableModel(data,cols);
	
	JTable jtb_mv = new JTable(dtm_mv) { //셀 수정 불가 메소드 선언
		public boolean isCellEditable(int row, int column) {
			return false;
		}
	};
		JTableHeader jth = jtb_mv.getTableHeader();
	JScrollPane jsp_mv = new JScrollPane(jtb_mv
			,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED
			,JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
	
	JPanel jp_south = new JPanel();
	JButton jbtn_exit = new JButton("닫기");
	
	MovieConfirm mc = null;
	
	MovieConfirmSeatDao mcsDao = null;

	public MovieConfirmSeat(MovieConfirm mc) {
		jbtn_exit.addActionListener(this);
		this.mc = mc;
		initDisplay();
		mcsDao = new MovieConfirmSeatDao(this);
		mcsDao.refreshDataSeat(this.mc.mmv.lf.id,this.mc.ticketNum);
	}

	public void initDisplay() {
		jp_south.add(jbtn_exit);
		this.add("Center", jsp_mv);
		this.add("South", jp_south);
		this.setSize(300,400);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		Object obj = e.getSource();
		if(obj == jbtn_exit) {
			this.dispose();
		}
		
	}
}
