package movie_project;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import movie_db.MovieDao;
import movie_db.PaymentDao;

public class Payment extends JFrame implements ActionListener {
	MovieMainView mmv = null;
	public SeatSelection ss = null;
	MovieDao md = null;
	public long ticketNum;
	PaymentDao payDao = new PaymentDao(this);
	
	JPanel jp_center = new JPanel();
	JPanel jp_south = new JPanel();
	
	String imgPath = "src\\movie_project\\";	
	JLabel jlb_img = new JLabel(new ImageIcon(imgPath + "팝콘2.png"));
	
	JLabel jlb_card = new JLabel("카드사");
			String[] card_name= {"선택","BC카드", "삼성카드", "신한카드", "현대카드", "하나카드", "국민카드", "롯데카드"};
		JComboBox jcb_card = new JComboBox(card_name);
	
	JLabel jlb_cdn = new JLabel("카드번호");
		JTextField jtf_cdn[] = new JTextField[4];
	JLabel jlb_expire = new JLabel("유효기간");
		JTextField jtf_expire = new JTextField(30);
	JLabel jlb_num = new JLabel("총 좌석수");
		JTextField jtf_num = new JTextField(30);
	JLabel jlb_price = new JLabel("결제금액");
		JTextField jtf_price = new JTextField(30);
	JLabel jlb_cvc = new JLabel("CVC코드");
		JTextField jtf_cvc = new JTextField(30);
	
	JButton jbtn_pre = new JButton("이전");
	JButton jbtn_payment = new JButton("결제하기");
	
	public Payment(SeatSelection ss) {
		this.ss = ss;
		initDisplay();
	}

	public void initDisplay() {
		jp_center.setLayout(null); // 레이아웃 뭉갬
		this.setLocation(600, 100);
		jp_center.setBackground(Color.WHITE);
		jp_south.setBackground(Color.WHITE);
		
		jbtn_pre.setBackground(Color.LIGHT_GRAY);
		jbtn_payment.setBackground(Color.LIGHT_GRAY);
		jlb_img.setBounds (90, 180, 120, 80); 
		jp_center.add(jlb_img);
		
		for(int i=0; i<jtf_cdn.length; i++) {
			jtf_cdn[i] = new JTextField(30);
		}
		
		jlb_card.setBounds (40, 20, 50, 20); 
		jlb_cdn.setBounds(40, 45 ,80  ,20);
		jlb_expire.setBounds(40, 70, 80, 20);
		jlb_cvc.setBounds(40, 95, 80, 20);
		jlb_num.setBounds(40, 125, 80, 20);
		jlb_price.setBounds(40, 150, 80, 20);
		
		jcb_card.setBounds (110, 20, 100, 20);
		jtf_cdn[0].setBounds(110, 45 ,40 ,20);
		jtf_cdn[1].setBounds(155, 45 ,40 ,20);
		jtf_cdn[2].setBounds(200, 45 ,40 ,20);
		jtf_cdn[3].setBounds(245, 45 ,40 ,20);
		jtf_expire.setBounds(110, 70, 100, 20);
		jtf_cvc.setBounds(110, 95, 100, 20);
		jtf_num.setBounds(110, 125, 100, 20);
		jtf_price.setBounds(110, 150, 100, 20);
		
		jp_center.add(jlb_card);
		jp_center.add(jcb_card);
		jp_center.add(jlb_cdn);
		for(int i=0; i<jtf_cdn.length; i++)
			jp_center.add(jtf_cdn[i]);
		jp_center.add(jlb_expire);
		jp_center.add(jtf_expire);
		jp_center.add(jlb_cvc);
		jp_center.add(jtf_cvc);
		jp_center.add(jlb_num);
		jp_center.add(jtf_num);
		jp_center.add(jlb_price);
		jp_center.add(jtf_price);
		
		jp_south.add(jbtn_pre);
		jp_south.add(jbtn_payment);
		
		jtf_num.setText(this.ss.select);
		jtf_num.setEnabled(false);
		jtf_price.setText(this.ss.amount);
		jtf_price.setEnabled(false);
		
		jbtn_pre.addActionListener(this);
		jbtn_payment.addActionListener(this);
		this.setTitle("결제");
		this.add("Center",jp_center);
		this.add("South",jp_south);
		this.setSize(330, 350);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
	}
	
	public int ranCom() { // 예매번호 로직
		return (int)(Math.random()*1000000);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Object obj = e.getSource();
		
		if(obj == jbtn_payment) { // 결제버튼
			for(int i=0; i<jtf_cdn.length; i++) {
				if(jtf_cdn[i].getText().length() == 0 || jtf_cdn[i].getText().length() != 4) {
					JOptionPane.showMessageDialog(null, "카드번호를 확인하세요!", "결제오류", JOptionPane.PLAIN_MESSAGE);
					return;
				}
			}
			if(jcb_card.getSelectedItem().toString() == "선택") {
				JOptionPane.showMessageDialog(null, "카드를 선택하세요!", "결제오류", JOptionPane.PLAIN_MESSAGE);
			}
			else if(jtf_expire.getText().length() == 0) {
				JOptionPane.showMessageDialog(null, "유효기간을 입력하세요!", "결제오류", JOptionPane.PLAIN_MESSAGE);
			}
			else if(jtf_cvc.getText().length() == 0) {
				JOptionPane.showMessageDialog(null, "cvc코드를 입력하세요!", "결제오류", JOptionPane.PLAIN_MESSAGE);
			}
			else if(jtf_cvc.getText().length() != 0 && jtf_cvc.getText().length() != 3) {
				JOptionPane.showMessageDialog(null, "cvc코드 3자리를 입력하세요.", "결제오류", JOptionPane.PLAIN_MESSAGE);
			}
			else if(jtf_price.getText().length() == 0) {
				JOptionPane.showMessageDialog(null, "결제금액을 입력하세요!", "결제오류", JOptionPane.PLAIN_MESSAGE);
			}
			else {
				String temp = ss.ds.cal_date + Integer.toString(ranCom());
				ticketNum = Long.parseLong(temp); // -2147483648 ~ 2147483647 이상은 long으로 해야함
				md = new MovieDao(this);
				JOptionPane.showMessageDialog(null, "결제가 완료되었습니다!\n 예매번호 : " + 
				ticketNum, "결제완료", JOptionPane.PLAIN_MESSAGE);
				mmv = new MovieMainView(this.ss.ds.md.ms.mmv.lf);
				this.dispose();
				
				for(int i=0; i<ss.seat_choice.length; i++) {
					payDao.insert(ticketNum, ss.seat_choice[i], ss.ds.cal_date, ss.ds.time_code, ss.ds.md.ms.mmv.lf.id);
//					System.out.println();
//					System.out.println("ticketNum : " + ticketNum);
//					System.out.println("ss.seat_choice[" + i + "] : " + ss.seat_choice[i]);
//					System.out.println("ss.ds.cal_date : " + ss.ds.cal_date);
//					System.out.println("ss.ds.time_code : " + ss.ds.time_code);
//					System.out.println("ss.ds.md.ms.mmv.lf.id : " +ss.ds.md.ms.mmv.lf.id);
				}
			
			}
		}
		if(obj == jbtn_pre) { // 뒤로가기
			ss = new SeatSelection(this.ss.ds);
			this.dispose();
		}
	}
}