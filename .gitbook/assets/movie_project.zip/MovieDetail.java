package movie_project;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import movie_db.MovieDao;
import movie_db.MovieVO;

public class MovieDetail extends JFrame implements ActionListener {
	
	JPanel jp_center = new JPanel();
	JLabel jlb_poster = null;
	JButton jbtn_pre = new JButton("이전");
	JButton jbtn_rsv = new JButton("예매하기");
	JLabel jlb_title = new JLabel("영화 제목");
	JLabel jlb_score = new JLabel("평점");
	JLabel jlb_act = new JLabel("감독 및 배우");
	JLabel jlb_time = new JLabel("러닝타임");
	JButton jbtn_story = new JButton("줄거리");
	
	JTextField jtf_title = new JTextField("mv_title");
	JTextField jtf_score = new JTextField("mv_score");
	JTextField jtf_act = new JTextField("mv_act");
	JTextField jtf_time = new JTextField("mv_time");
	
	public MovieSelection ms = null;
	DateSelection ds = null;
	MovieDao mdo = new MovieDao(this);
	MovieVO mv = null;
	
	public MovieDetail(MovieSelection ms) {
		this.ms = ms;
		jlb_poster = new JLabel(this.ms.icon);
		mv = mdo.detail(ms.mv_code);
		initDisplay();
	}
	
	public void setMv_detail() { //텍스트 필드 값 설정하는 함수
		jtf_title.setText(mv.getMv_title());
		jtf_score.setText(Integer.toString(mv.getMv_score()));
		jtf_act.setText(mv.getMv_act());
		jtf_time.setText(mv.getMv_time());
	}
	
	public void initDisplay() {
		jp_center.setLayout(null);
		jp_center.setBackground(Color.WHITE);
		jbtn_rsv.addActionListener(this);
		jbtn_pre.addActionListener(this);
		jbtn_story.addActionListener(this);
		jlb_poster.setBounds(40,30,200,300);
		setMv_detail(); //텍스트 필드 값 설정
		
		jlb_title.setBounds(260,50,200,20);
		jtf_title.setBounds(260,70,200,20);
			jtf_title.setOpaque(true);
			jtf_title.setBackground(Color.WHITE);
			
		jlb_score.setBounds(260,110,200,20);
		jtf_score.setBounds(260,130,200,20);
			jtf_score.setOpaque(true);
			jtf_score.setBackground(Color.WHITE);
			
		jlb_act.setBounds(260,170,200,20);
		jtf_act.setBounds(260,190,200,20);
			jtf_act.setOpaque(true);
			jtf_act.setBackground(Color.WHITE);
			
		jlb_time.setBounds(260,230,200,20);
		jtf_time.setBounds(260,250,200,20);
			jtf_time.setOpaque(true);
			jtf_time.setBackground(Color.WHITE);
			
		jbtn_story.setBounds(310, 290, 100, 30);
		jbtn_pre.setBounds(140, 400, 100, 30);
		jbtn_rsv.setBounds(260, 400, 100, 30);
		jbtn_story.setBackground(Color.LIGHT_GRAY);
		jbtn_pre.setBackground(Color.LIGHT_GRAY);
		jbtn_rsv.setBackground(Color.LIGHT_GRAY);
		
		
		jp_center.add(jbtn_story);
		jp_center.add(jlb_title);
		jp_center.add(jlb_act);
		jp_center.add(jlb_score);
		jp_center.add(jlb_time);
		
		jp_center.add(jtf_title);
		jp_center.add(jtf_act);
		jp_center.add(jtf_score);
		jp_center.add(jtf_time);
		
		jp_center.add(jbtn_pre);
		jp_center.add(jbtn_rsv);
		jp_center.add(jlb_poster);
		
		this.add("Center",jp_center);
		this.setSize(500, 500);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Object obj = e.getSource();
		if(obj == jbtn_rsv) { //예매하기 버튼
			this.dispose();
			ds = new DateSelection(this);
		}

		else if(obj == jbtn_pre) { //이전 버튼
			this.dispose();
			ms = new MovieSelection(this.ms.mmv);
		}
		
		else if(obj == jbtn_story) { //줄거리 버튼
			JDialog jd = new JDialog();
				JPanel jp_jd = new JPanel();
				jp_jd.setLayout(new BorderLayout());
					JScrollPane jsp_display = new JScrollPane(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, 
															  JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
							JTextArea jta_display = new JTextArea();
							jta_display.setLineWrap(true);
			jsp_display = new JScrollPane(jta_display);
			jp_jd.add("Center",jsp_display);
			jd.add("Center", jp_jd);
			jd.setSize(300, 300);
			jta_display.append(mv.getMv_story());
			jd.setLocationRelativeTo(null);
			jd.setVisible(true);
		}
	}
}