package movie_project;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JTextField;

import movie_db.MovieDao;
import movie_db.SeatSelectionDao;

public class SeatSelection extends JFrame implements ActionListener {
	String imgPath = "src\\movie_test\\";
	
	JPanel jp_north = new JPanel(new FlowLayout());
		JLabel jlb_scr = new JLabel();
	JPanel jp_center = new JPanel();
		JButton jbtn_seat[] = new JButton[50];
	JPanel jp_south = new JPanel(new BorderLayout());
		JPanel jp_pay = new JPanel();
			JLabel jlb_seat = new JLabel("선택한 좌석수");
			JTextField jtf_seat = new JTextField(5);
			JLabel jlb_amount = new JLabel("총 결제금액");
			public JTextField jtf_amount = new JTextField(10);
		JPanel jp_next = new JPanel();
			JButton jbtn_pre = new JButton("이전");
			JButton jbtn_next = new JButton("다음");
		
	public DateSelection ds = null;
	public SeatSelectionDao ssDao = new SeatSelectionDao(this);
	MovieDao mdo = null;
	Payment pm = null;

	public String seat_choice[]; // 선택한 좌석들을 저장.
	int seat_size; //선택한 좌석들의 크기를 지정할 변수
	int change = 0; // 선택된 좌석이 있으면 1, 없으면 0
	int sel = 0; // 선택한 좌석수와 금액을 나타내기 위한 변수
	String select; // 총 좌석수
	String amount; // 총 금액
	int x = 0;
	String[] selectSeat = null; 
	
	public SeatSelection(DateSelection ds) {
		this.ds = ds;
		initDisplay();
	}

	public String seatCol(int j) { // 좌석이름 만드는 함수
		if(j<9) {
			if(j%8==0)
				return "A8";
			return "A" + Integer.toString(j%8);
		}
		else if(j<17) {
			if(j%8==0)
				return "B8";
			return "B" + Integer.toString(j%8);
		}
		else if(j<25) {
			if(j%8==0)
				return "C8";
			return "C" + Integer.toString(j%8);
		}
		else if(j<33) {
			if(j%8==0)
				return "D8";
			return "D" + Integer.toString(j%8);
		}
		else {
			if(j%8==0)
				return "E8";
			return "E" + Integer.toString(j%8);
		}
	}
	
	public void initDisplay() {
		int j = 0;
		for(int i=0; i<jbtn_seat.length; i++) {
			if(i%10==3 || i%10==6) { // 4, 7번째를 통로버튼으로 만듬
				jbtn_seat[i] = new JButton();
				jbtn_seat[i].setPreferredSize(new Dimension(50, 30));
				jbtn_seat[i].setEnabled(false);
				jp_center.add(jbtn_seat[i]);
				continue;
			}
			// 좌석버튼 만드는 구간
			j++;
			String seat = seatCol(j);
			jbtn_seat[i] = new JButton(seat);
			jbtn_seat[i].setPreferredSize(new Dimension(50, 30));
			jbtn_seat[i].setBackground(Color.GRAY);
			jbtn_seat[i].addActionListener(this);
			jp_center.add(jbtn_seat[i]);
		}
		
		ssDao.seat(ds.cal_date, ds.time_code);
		
		for(int i=0; i<jbtn_seat.length; i++) {
			for(int x=0; x<ssDao.checkSeat.length;x++) {
				if(jbtn_seat[i].getText().equals(ssDao.checkSeat[x])){
					jbtn_seat[i].setEnabled(false);
					jbtn_seat[i].setBackground(Color.LIGHT_GRAY);
				}
			}
		}	
		
		jlb_scr.setOpaque(true);
		jlb_scr.setBackground(Color.DARK_GRAY);
		jlb_scr.setPreferredSize(new Dimension(350, 200));
		jlb_scr.setText("Screen");
		jlb_scr.setHorizontalAlignment(JLabel.CENTER);
		jlb_scr.setForeground(Color.WHITE);
		jlb_scr.setFont(new Font("Dialog", Font.PLAIN, 40));
		
		jp_pay.add(jlb_seat);
		jp_pay.add(jtf_seat);
		jtf_seat.setEnabled(false);
		jp_pay.add(jlb_amount);
		jp_pay.add(jtf_amount);
		jtf_amount.setEnabled(false);
		jp_north.add(jlb_scr);
		jp_south.add("Center", jp_pay);
		jp_south.add("South", jp_next);
		jp_next.add(jbtn_pre);
		jp_next.add(jbtn_next);
		jbtn_pre.addActionListener(this);
		jbtn_next.addActionListener(this);
		
		//현재 상영중인 영화에 대한 mv_code를 Dao로 넘겨서
		//mv_code는 MovieSelection클래스에 있음.
		//DB로 부터 해당 영화의 상영관의 점유된 좌석값들을 받아오고 그것을 String배열에 받음.
		//그리고 그 String 배열에 담긴 값들과 똑같은 text값을 가진 좌석버튼들을 setEnable상태로 바꿔준다.
		
		this.setSize(600, 600);
		this.setLayout(new BorderLayout(20,20));
		this.add("North", jp_north);
		this.add("Center",jp_center);
		this.add("South",jp_south);
		this.setResizable(false);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		Object obj = e.getSource();
		
		for(int i=0; i<jbtn_seat.length; i++) {
			if(obj == jbtn_seat[i]) { // 좌석버튼 눌렀을 때,
				
				if(jbtn_seat[i].getBackground() == Color.BLACK) { // 좌석 선택되있을 때 (=좌석명이 null일 때) 
					jbtn_seat[i].setBackground(Color.GRAY); // 배경색 원래대로
					jbtn_seat[i].setForeground(null);
					change--;
					sel--;
					if(sel==0) {
						jtf_seat.setText(null);
						jtf_amount.setText(null);
					}
					select = Integer.toString(sel);
					amount = Integer.toString(sel*10000);
					jtf_seat.setText(select);
					jtf_amount.setText(amount);
					seat_size--;
					x = 0;
					return;
				}
				
				//좌석이 선택 안되있을 때
				jbtn_seat[i].setBackground(Color.BLACK); // 배경색 검정색으로
				jbtn_seat[i].setForeground(Color.WHITE);
				change++;
				sel++;
				select = Integer.toString(sel);
				amount = Integer.toString(sel*10000);
				jtf_seat.setText(select);
				jtf_amount.setText(amount);
				seat_size++;
			}
		}
		
		if(obj == jbtn_next) { // 다음버튼 눌렀을 때
			if(change==0) {
				System.out.println("좌석을 1석 이상 선택하세요.");
				return;
			}
			seat_choice = new String[seat_size];
			int j = 0;
			for(int i = 0; i<jbtn_seat.length; i++) {
				if(jbtn_seat[i].getBackground() == Color.BLACK) { // 좌석명이 없는번호 산출
					seat_choice[j] = jbtn_seat[i].getText(); // 선택한 좌석의 문자열 값들을 seat_choice배열에 저장
					j++;
				}
			}
			for(int i=0; i<seat_choice.length; i++)
				System.out.println(seat_choice[i]);
			pm = new Payment(this);
			this.dispose();
		}
		
		else if(obj == jbtn_pre) { // 이전 버튼
			ds = new DateSelection(this.ds.md);
			this.dispose();
		}
	}
}
