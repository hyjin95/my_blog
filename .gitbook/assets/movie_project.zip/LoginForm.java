package movie_project;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import movie_db.MovieDao;

public class LoginForm extends JFrame implements ActionListener {
	//선언부
	MovieMainView mmv = null;
	MemberShip ms = null;
	JLabel jlb_id = new JLabel("아이디");
	JLabel jlb_pw = new JLabel("비밀번호");
	JTextField jtf_id = new JTextField("test");
	JPasswordField jpf_pw = new JPasswordField("123");
	JButton jbtn_login = 
			new JButton("로그인");
	JButton jbtn_join = 
			new JButton("회원가입");
	String imgPath = "src\\movie_project\\";	
	JLabel jlb_img = new JLabel(new ImageIcon(imgPath + "팝콘.png"));
	JPanel jp_center = new JPanel();
	
	MovieDao mdo = new MovieDao(this);
	public String id; //id 저장
	int result;
	
	//생성자
	public LoginForm() {
		initDisplay();
	}
	//화면처리부
	public void initDisplay() {
		
		jp_center.setLayout(null);
		jp_center.setBackground(Color.WHITE);
		jlb_img.setBounds(20, 10, 300, 200);
		jp_center.add(jlb_img);
		jbtn_login.setBackground(Color.LIGHT_GRAY);
		jbtn_join.setBackground(Color.LIGHT_GRAY);
		jbtn_login.addActionListener(this);
		jbtn_join.addActionListener(this);
		jlb_id.setBounds(45, 200, 80, 40);
		jp_center.add(jlb_id);
		jtf_id.setBounds(110, 200, 185, 40);
		jp_center.add(jtf_id);
		jlb_pw.setBounds(45, 240, 80, 40);
		jp_center.add(jlb_pw);
		jpf_pw.setBounds(110, 240, 185, 40);
		jp_center.add(jpf_pw);
		jbtn_join.setBounds(45, 285, 120, 40);
		jp_center.add(jbtn_join);
		jbtn_login.setBounds(175, 285, 120, 40);
		jp_center.add(jbtn_login);		
		this.add("Center", jp_center);
		this.setSize(350, 600);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
	}
	
	//메인메소드
	public static void main(String[] args) {
		new LoginForm();
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		Object obj = e.getSource();//이벤트가 감지된 주소번지 담기
		if(obj == jbtn_join) {
			ms = new MemberShip();
		}
		else if(obj == jbtn_login) { // 로그인 클릭
			if(jtf_id.getText().length()==0) { // id입력 안했을 때
				JOptionPane.showMessageDialog(null, 
						"아이디를 입력하세요!", "아이디 확인", JOptionPane.PLAIN_MESSAGE);
				return;
			}
			else if(jpf_pw.getText().length()==0) { // pw입력 안했을 때
				JOptionPane.showMessageDialog(null, 
						"패스워드를 입력하세요!", "패스워드 확인", JOptionPane.PLAIN_MESSAGE);
				return;
			}
			
			else { // id, pw 모두 입력
				result = mdo.login(jtf_id.getText(), jpf_pw.getText()); //Dao에서 login함수 값 return
				if(result == 0) { //해당 정보가 없을 경우
					JOptionPane.showMessageDialog(null, 
							"아이디나 패스워드가 일치하지 않습니다.", "정보상이", JOptionPane.PLAIN_MESSAGE);
					return;
				}
				// 정보가 있을 경우
				id = jtf_id.getText();
				mmv = new MovieMainView(this);
				this.dispose();
			}
		}
	}
}
