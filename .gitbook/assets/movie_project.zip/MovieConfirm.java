package movie_project;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

import movie_db.MovieConfirmDao;

public class MovieConfirm extends JFrame implements ActionListener, MouseListener {
	String data[][] = new String[0][5];
	String cols[] = {"예매번호", "날짜", "상영관", "상영시간", "상영영화"};
	public DefaultTableModel dtm_mv = new DefaultTableModel(data,cols);
	
	JTable jtb_mv = new JTable(dtm_mv) { //셀 수정 불가 메소드 선언
		public boolean isCellEditable(int row, int column) {
			return false;
		}
	};
		JTableHeader jth = jtb_mv.getTableHeader();
	JScrollPane jsp_mv = new JScrollPane(jtb_mv
			,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED
			,JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
	
	JPanel jp_south = new JPanel();
	JButton jbtn_pre = new JButton("이전");
	JButton jbtn_cancel = new JButton("예매취소");
	
	MovieMainView mmv = null;
	MovieConfirmDao mcDao = null;
	MovieConfirmSeat mcs = null;
	
	String ticketNum;

	public MovieConfirm(MovieMainView mmv) {
		this.mmv = mmv;
		mcDao = new MovieConfirmDao(this);
		initDisplay();
	}
	
	public void initDisplay() {
		mcDao.refreshData(this.mmv.lf.id);
		jtb_mv.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		jtb_mv.addMouseListener(this);
		jbtn_cancel.addActionListener(this);
		jbtn_pre.addActionListener(this);
		jbtn_cancel.setPreferredSize(new Dimension(100, 30));	
		jbtn_pre.setPreferredSize(new Dimension(100, 30));	
		jp_south.add(jbtn_cancel);
		jp_south.add(jbtn_pre);
		this.add("Center", jsp_mv);
		this.add("South", jp_south);
		this.setSize(500,500);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Object obj = e.getSource();
		
		if(obj == jbtn_pre) { //이전 버튼
			this.dispose();
			mmv = new MovieMainView(this.mmv.lf);
		}
		
		else if(obj == jbtn_cancel) { //취소 눌렀을 때
			if(dtm_mv.getRowCount()==0) {
				JOptionPane.showMessageDialog(null, 
						"예매건이 없습니다.", "에러", JOptionPane.PLAIN_MESSAGE);
				return;
			}
			else if (jtb_mv.getSelectedRowCount()==0) {
				JOptionPane.showMessageDialog(null, 
						"예매건을 선택하세요.", "에러", JOptionPane.PLAIN_MESSAGE);
				return;
			}
			mcDao.deleteRsv(ticketNum, mmv.lf.id);
			JOptionPane.showMessageDialog(null, 
					"예매가 취소되었습니다.", "예매취소", JOptionPane.PLAIN_MESSAGE);
			dtm_mv.setNumRows(0);
			mcDao.refreshData(this.mmv.lf.id);
		}
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		if(e.getClickCount() == 1) {
			int row = jtb_mv.getSelectedRow();
			ticketNum = String.valueOf(jtb_mv.getModel().getValueAt(row, 0));
			System.out.println("한 번 클릭함. ticketNum : " + ticketNum);
		} 
		
		else if(e.getClickCount()==2) {
			int row = jtb_mv.getSelectedRow();
			ticketNum = String.valueOf(jtb_mv.getModel().getValueAt(row, 0));
			System.out.println("더블 클릭함. ticketNum : " + ticketNum);
			mcs = new MovieConfirmSeat(this);
		}	
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

}
