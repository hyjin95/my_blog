package movie_project;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class MovieMainView extends JFrame implements ActionListener {
	MovieConfirm mc = null;
	MovieSelection ms = null;
	public LoginForm lf = null;
	
	JButton jbtn_logout = new JButton("로그아웃");
	JButton jbtn_reservation = new JButton("예매하기");
	JButton jbtn_confirm = new JButton("예매확인");
	JButton jbtn_exit = new JButton("종료");
	
//	String imgPath="src\\movie_project\\";
	String imgPath="src\\\\movie_project\\\\";
	ImageIcon iicon = new ImageIcon(imgPath+"cinema1.png");
	
	class MyPicture extends JPanel{  //내부클래스
		public void paintComponent(Graphics g) {
			g.drawImage(iicon.getImage(),0 , 0, null);
			setOpaque(false);
			super.paintComponent(g);
		}		
	}
	
	public MovieMainView(LoginForm lf) {
		this.lf = lf;
		initDisplay();
	}

	public void initDisplay() {
		setContentPane(new MyPicture());
		this.setLayout(null);
		
		jbtn_logout.setBounds(210, 30, 100, 35);
		jbtn_reservation.setBounds(125, 230, 100, 35);
		jbtn_confirm.setBounds(125, 280, 100, 35);
		jbtn_exit.setBounds(125, 500, 100, 35);
		
		jbtn_logout.setBackground(Color.WHITE);
		jbtn_reservation.setBackground(Color.WHITE);
		jbtn_confirm.setBackground(Color.WHITE);
		jbtn_exit.setBackground(Color.WHITE);
		
		this.add(jbtn_logout);
		this.add(jbtn_reservation);
		this.add(jbtn_confirm);
		this.add(jbtn_exit);
		
		jbtn_logout.addActionListener(this);
		jbtn_confirm.addActionListener(this);
		jbtn_reservation.addActionListener(this);
		jbtn_exit.addActionListener(this);
		this.setSize(350, 600);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		Object obj = e.getSource();
		//====================================================
		if (obj == jbtn_logout) { //로그아웃 버튼
			lf = new LoginForm();
			this.dispose();
		}
		else if (obj == jbtn_reservation) { //예매하기 버튼
			ms = new MovieSelection(this);
			this.dispose();
		}
		else if (obj == jbtn_confirm) { //예매확인 버튼
			mc = new MovieConfirm(this);
			this.dispose();
		}
		else if (obj == jbtn_exit) { //종료 버튼
			System.exit(0);
		}
		//====================================================
	}
}