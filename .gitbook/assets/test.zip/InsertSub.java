package movie.test;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;

public class InsertSub extends JFrame implements ActionListener {

	JLabel jlb_ins = new JLabel("영화 예매");

	JButton jbtn_ins = new JButton("예매");
	JButton jbtn_exit = new JButton("종료");
	JPanel jp_north = new JPanel();
	JPanel jp_south = new JPanel();

	JScrollPane scrollPane = new JScrollPane();
	JScrollBar scrollBar = new JScrollBar();
	
	public void initDisplay() {
		
		jp_south.setLayout(new FlowLayout(FlowLayout.RIGHT));
		
		jp_north.add(jlb_ins);
		jp_south.add(jbtn_ins);
		jp_south.add(jbtn_exit);

		jbtn_exit.addActionListener(this);
		jbtn_ins.addActionListener(this);

		this.add("North", jp_north);
		this.add("South", jp_south);
		
		this.add(scrollBar, BorderLayout.EAST);

		this.setTitle("영화 예매");
		this.setSize(500, 500);
		this.setVisible(true);
	}

	public static void main(String[] args) {
		InsertSub is = new InsertSub();
		is.initDisplay();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Object obj = e.getSource();
//		MovieSeat ms = new MovieSeat();
		Pay p = new Pay();
		p.initDisplay();
		
		
		if (obj == jbtn_ins) {
			p.initDisplay();
		}
		if (obj == jbtn_exit) {
			System.exit(0);
		}
	}
}
