package movie.test;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;

public class Pay extends JDialog implements ActionListener {
	
	JScrollPane jspLine = null;
//	JScrollPane jspLine = new JScrollPane();
	JPanel jp_south = new JPanel();
	JButton jbtn_exit = new JButton("닫기");
	JButton jbtn_save = new JButton("저장");
	JButton jbtn_a = new JButton("카드");

	JTextField jtf_cb = new JTextField(6);
	JLabel jlb_cb = new JLabel("카드사"); 
	
	JTextField jtf_cn = new JTextField(30);
	JLabel jlb_cn = new JLabel("카드번호");
	
	JTextField jtf_date = new JTextField(30);
	JLabel jlb_date = new JLabel("유효기간");
	
	JPanel jp_center = new JPanel();
	public void initDisplay() {
		
		
		jp_center.setLayout(null);
		jlb_cb.setBounds (20, 20, 50, 20); 
		jtf_cb.setBounds (80, 20, 100, 20);
		jlb_cn.setBounds(20, 45 ,80  ,20);
		jtf_cn.setBounds(80, 45 ,100 ,20);
		jbtn_a.setBounds  (80, 95, 100, 20 );
		jlb_date.setBounds(20, 70, 80, 20);
		jtf_date.setBounds(80, 70, 100, 20);
		jp_center.add(jlb_cb);
		jp_center.add(jtf_cb);
		jp_center.add(jlb_cn);
		jp_center.add(jtf_cn);
		jp_center.add(jlb_date);
		jp_center.add(jtf_date);
		jp_center.add(jbtn_a);
		
		jbtn_exit.addActionListener(this);
		jbtn_save.addActionListener(this);
//		jbtn_a.addActionListener(this);
		jspLine = new JScrollPane(jp_center);
		
		jp_south.add(jbtn_exit);
		this.setTitle("상세보기");
		this.add("Center", jspLine);
		this.add("South",jp_south);
		this.setSize(400, 300);
		this.setVisible(true);
		
		
		
	}
	
	
	
	
	
	public static void main(String[] args) {
		Pay p2 = new Pay();
		p2.initDisplay();
		
	}





	@Override
	public void actionPerformed(ActionEvent e) {
		Object obj = e.getSource();
		
		if(obj == jbtn_exit) {
			System.exit(0);
		}
		
	}
}
