package movie.test;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;

public class ListSub extends JFrame implements ActionListener {
	Image img;
	
	JLabel jlb_list = new JLabel("영화 목록");

	JButton jbtn_exit = new JButton("종료");
	JPanel jp_north = new JPanel();
	JPanel jp_south = new JPanel();
	JPanel jp_center = new JPanel();
	JPanel jp_east = new JPanel();
	JPanel jp_west = new JPanel();
	JScrollPane scrollPane = new JScrollPane();
	JScrollBar scrollBar = new JScrollBar();
	public void initDisplay() {
		
		
		jp_south.setLayout(new FlowLayout(FlowLayout.RIGHT));
		jp_north.add(jlb_list);
		jp_south.add(jbtn_exit);
		
		jbtn_exit.addActionListener(this);

		this.add("North", jp_north);
		this.add("South", jp_south);
		
		this.add(scrollBar, BorderLayout.EAST);
		
		
		this.setTitle("영화 목록");
		this.setSize(500, 500);
		this.setVisible(true);
	}

	public static void main(String[] args) {
		ListSub ls = new ListSub();
		ls.initDisplay();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Object obj = e.getSource();
		if (obj == jbtn_exit) {
			System.exit(0);
		}

	}
}
