package movie.test; //첫화면

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;

public class MovieTestView extends JFrame implements ActionListener {
	JMenuBar jmb      = new JMenuBar();
	JMenu jm          = new JMenu("Edit");
	JMenuItem jmi_1   = new JMenuItem("1");
	JMenuItem jmi_2   = new JMenuItem("2");
	JMenuItem jmi_3   = new JMenuItem("3");

	JButton jbtn_list = new JButton("영화 목록");
	JButton jbtn_ins  = new JButton("영화 예매");
	JButton jbtn_det  = new JButton("예매 확인");

	JButton jbtn_exit = new JButton("종료");

	JPanel jp         = new JPanel();
	JPanel jp_south   = new JPanel();
	JPanel jp_east    = new JPanel();

	public void initDisplay() {

		jm.add(jmi_1);
		jm.add(jmi_2);
		jm.add(jmi_3);
		jmb.add(jm);

		jp.setLayout(new FlowLayout(FlowLayout.CENTER));
		jp_south.setLayout(new FlowLayout(FlowLayout.RIGHT));
		jp.add(jbtn_list);
		jp.add(jbtn_ins);
		jp.add(jbtn_det);
		jp_south.add(jbtn_exit);
		jbtn_list.addActionListener(this);
		jbtn_ins.addActionListener(this);
		jbtn_det.addActionListener(this);
		jbtn_exit.addActionListener(this);

		this.setJMenuBar(jmb);
		this.add("Center", jp);
		this.add("South", jp_south);
		this.setTitle("Movie Ver 1.0");
		this.setSize(500, 500);
		this.setVisible(true);

	}

	public static void main(String[] args) {
		MovieTestView mtv = new MovieTestView();
		mtv.initDisplay();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Object obj = e.getSource();

		ListSub ls = new ListSub();
		InsertSub is = new InsertSub();
		DetailSub ds = new DetailSub();

		if (obj == jbtn_list) {
			ls.initDisplay();
			System.out.println("영화 예매 호출 성공");
		}
		if (obj == jbtn_ins) {
			is.initDisplay();
			System.out.println("영화 예매 호출 성공");
		}
		if (obj == jbtn_det) {
			ds.initDisplay();
			System.out.println("예매 확인 호출 성공");
		}
		if (obj == jbtn_exit) {
			System.exit(0);
		}
	}
}