package movie.test;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class DetailSub extends JFrame implements ActionListener {

	JLabel jlb_det = new JLabel("예매 확인");

	JButton jbtn_exit = new JButton("종료");
	JPanel jp_north = new JPanel();
	JPanel jp_south = new JPanel();

	public void initDisplay() {
		jp_south.setLayout(new FlowLayout(FlowLayout.RIGHT));
		
		jp_north.add(jlb_det);
		jp_south.add(jbtn_exit);

		jbtn_exit.addActionListener(this);

		this.add("North", jp_north);
		this.add("South", jp_south);
		this.setTitle("예매 확인");
		this.setSize(500, 500);
		this.setVisible(true);
	}

	public static void main(String[] args) {
		DetailSub ds = new DetailSub();
		ds.initDisplay();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Object obj = e.getSource();
		if (obj == jbtn_exit) {
			System.exit(0);
		}

	}
}
