package movie_db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import movie_project.LoginForm;
import movie_project.MovieDetail;
import movie_project.Payment;

public class MovieDao {
	DBConnectionMgr dbMgr = null;
	Connection con 			= null;
	PreparedStatement pstmt = null;
	ResultSet rs 			= null;
	LoginForm lf = null;
	MovieDetail md = null;
	Payment pm = null;
	int result;
	
	public MovieDao(LoginForm lf) {
		this.lf = lf;
	}

	public MovieDao(MovieDetail md) {
		this.md = md;
	}
	
	public MovieDao(Payment pm) {
		this.pm = pm;
	}

//	public void setRegister() { // 결제완료후 DB에 예매내역 저장하는 함수
//		MovieVO mVO[] = null;
//		dbMgr = DBConnectionMgr.getInstance();
//		StringBuilder sql = new StringBuilder();
//		
//		for(int i=0; i<pm.ss.seat_choice.length; i++) { //예매번호와 좌석번호가 복합키
//			sql.append("INSERT INTO TICKET "); //예매번호, 좌석번호, 날짜, 상영시간, 아이디 입력
//			sql.append("VALUES (" + pm.ticketNum + ", '" + pm.ss.seat_choice[i] + "', '" + pm.ss.ds.sel_date +"', '");
//			sql.append(pm.ss.ds.sel_time + "', '" + pm.ss.ds.md.ms.mmv.lf.id + "'");
//			int result = 0;
//			try {//인터넷이 끊겼을 경우 에러 발생
//				//전령 객체 메모리에 로딩
//				pstmt = con.prepareStatement(sql.toString());
//				//전령객체를 로딩할 때 파라미터로 select문을 전달했다.
//				//그 문을 처리해 주세요. 만일 insert할때는 executeUpdate호출함.
//				result = pstmt.executeUpdate();
//				} catch (Exception e) {
////				System.out.println("Exceptioin : "+e.toString());
//				System.out.println("MovieDao.setRegister() 메소드 작성중");
//			}
//		}
//	}
	
	public int getMemID(String id) {//아이디 중복체크 메서드
		MovieVO mVO[] = null;
		dbMgr = DBConnectionMgr.getInstance();			
		StringBuilder sql = new StringBuilder();			
		sql.append("SELECT NVL((SELECT 1 FROM MEMBER WHERE mem_id =?),0)res FROM dual");
		try {
			con = dbMgr.getConnection();
			pstmt = con.prepareStatement(sql.toString());
			pstmt.setNString(1,  id);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				result = rs.getInt("res");					
			}
		} catch (Exception e) {
				System.out.println("Exception : "+e.toString());
			} finally {
				if(pstmt!=null) {
					try {
						pstmt.close();
					}catch(Exception e2) {
						
					}
				}
				if(con!=null) {
					try {
						con.close();
					} catch (Exception e2) {
						
					}
				}
			}			
		return result;
	}
	
	public MovieVO detail(String mv_code) {
		dbMgr = DBConnectionMgr.getInstance();
		con = dbMgr.getConnection();
		StringBuilder sql = new StringBuilder();
		MovieVO mVO = null;
		sql.append("SELECT MV_TITLE, MV_SCORE, MV_ACT, MV_STORY, MV_TIME ");
		sql.append("FROM MOVIE WHERE MV_CODE = ?"); 
		try {
			pstmt = con.prepareStatement(sql.toString());
			pstmt.setString(1, mv_code);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				mVO = new MovieVO();
				mVO.setMv_title(rs.getString("MV_TITLE"));
				mVO.setMv_score(rs.getInt("MV_SCORE"));
				mVO.setMv_act(rs.getString("MV_ACT"));
				mVO.setMv_story(rs.getString("MV_STORY"));
				mVO.setMv_time(rs.getString("MV_TIME"));
			}
		} catch (Exception e) {
			System.out.println(e.toString());			
		}
		return mVO;
	}
	
	public int login(String id, String pw) {
		dbMgr = DBConnectionMgr.getInstance();
		con = dbMgr.getConnection();
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT NVL((SELECT 1 FROM MEMBER WHERE MEM_ID =? AND MEM_PW =?),0)res FROM dual"); 
		try {
			con = dbMgr.getConnection();
			pstmt = con.prepareStatement(sql.toString());
			pstmt.setNString(1, id);
			pstmt.setNString(2, pw);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				result = rs.getInt("res");					
			}
		} catch (Exception e) {
				System.out.println("Exception : "+e.toString());
			} finally {
				if(pstmt!=null) {
					try {
						pstmt.close();
					} catch(Exception e2) {
						
					}
				}
				if(con!=null) {
					try {
						con.close();
					} catch (Exception e2) {
						
					}
				}
			}
		return result;
	}
}
