package movie_db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import movie_project.MovieConfirm;

public class MovieConfirmDao {
	
	DBConnectionMgr dbMgr = null;
	Connection con 			= null;
	PreparedStatement pstmt = null;
	ResultSet rs 			= null;
	MovieConfirm mc = null;

	public MovieConfirmDao(MovieConfirm mc) {
		this.mc = mc;
	}
	
	public void deleteRsv(String ticketNum, String id) {
		DBConnectionMgr dbMgr = DBConnectionMgr.getInstance();
		con = dbMgr.getConnection();
		StringBuilder sql = new StringBuilder();
		
		sql.append("delete from ticket tc							");
		sql.append(" where tc.ticket_num = ? AND tc.mem_id = ?	");
		
		try {
			pstmt = con.prepareStatement(sql.toString());
			pstmt.setNString(1, ticketNum);
			pstmt.setNString(2, id);
			rs = pstmt.executeQuery();
		}
		catch (Exception e) {
			System.out.println("Exceptioin : "+e.toString());
		}
	}

	public void refreshData(String id) {
		DBConnectionMgr dbMgr = DBConnectionMgr.getInstance();
		con = dbMgr.getConnection();
		StringBuilder sql = new StringBuilder();
		
		//중복된 값을 제거한 TICKET테이블에서 ticket_num을 조회함. (좌석번호는 포함하고 있지 않음);
		sql.append("SELECT DISTINCT TC.TICKET_NUM, TC.CAL_DATE, THE.THE_ROOM, TI.TIME_START, MV.MV_TITLE      ");
		sql.append("FROM TICKET TC, TIME TI, MEMBER M, MOVIE MV, THEATER THE                                  ");
		sql.append("WHERE TC.MEM_ID = M.MEM_ID AND TC.TIME_CODE = TI.TIME_CODE AND                            ");
		sql.append("TI.THE_ROOM = THE.THE_ROOM AND THE.MV_CODE = MV.MV_CODE AND TC.MEM_ID =:X                 ");
		sql.append("ORDER BY TC.TICKET_NUM ASC                                                                ");
		try {
			pstmt = con.prepareStatement(sql.toString());
			pstmt.setNString(1, id);
			rs = pstmt.executeQuery();
			if(rs == null) {
				mc.dtm_mv.setNumRows(0);
			}
			Vector<MovieVO> v = new Vector<>();
			MovieVO mVOS[] = null;
			MovieVO mVO = null;
			while(rs.next()) {
				mVO = new MovieVO();
				mVO.setTicket_num(rs.getLong("TICKET_NUM"));
				mVO.setCal_date(rs.getString("CAL_DATE"));
				mVO.setThe_room(rs.getString("THE_ROOM"));
				mVO.setTime_start(rs.getString("TIME_START"));
				mVO.setMv_title(rs.getString("MV_TITLE"));
				v.add(mVO);
			}
			mVOS = new MovieVO[v.size()];
			v.copyInto(mVOS);
			//질문:두 번 조회할 경우 앞에 조회결과가 남아 있어요. 이것을 초기화 하고 싶습니다. 
			//어떡하죠?
			//조회된 결과를 DefaultTableModel에 매칭시키기
			for(int x=0; x<mVOS.length; x++) {
				Vector<Object> oneRow = new Vector<>();
				oneRow.add(0,mVOS[x].getTicket_num());
				oneRow.add(1,mVOS[x].getCal_date());
				oneRow.add(2,mVOS[x].getThe_room());
				oneRow.add(3,mVOS[x].getTime_start());
				oneRow.add(4,mVOS[x].getMv_title());
				mc.dtm_mv.addRow(oneRow);
			}
		} catch (SQLException se) {
			System.out.println(se.toString());
			System.out.println("[[query]]=="+sql.toString());
		} catch (Exception e) {
			System.out.println(e.toString());			
		}
	}
}
