package movie_db;

public class MovieVO {
	  private String mv_code        = null;
	  private String mv_title       = null;
	  private int    mv_score       = 0;
	  private String mv_act         = null;
	  private String mv_story       = null;
	  private String mv_time        = null;
	  
	  private String the_code       = null;
	  private String the_room       = null;
	  private String mv_code_fk     = null;
	  
	  private String time_code      = null;
	  private String time_start     = null;
	  private String time_end       = null;
	  private String the_code_fk    = null;
	  
	  private String seat_num       = null;
	  private String time_code_fk   = null;
	  
	  private String ticket_code    = null;
	  private String cal_date 		= null;
	  private String calendar       = null;
	  private String seat_num_fk    = null;
	  
	  private long    ticket_num     = 0;
	  private String ticket_code_fk = null;
	  private String mem_id_fk      = null;
	  
	  private String mem_name       = null;
	  private String mem_tel        = null;
	  private String mem_id         = null;
	  private String mem_pw         = null;
	  private int    uid_no_fk      = 0;
	  private int    ticket_num_fk  = 0;
	 
	  private int    uid_no         = 0;
	  private int    zipcode        = 0;
	  private String zdo            = null;
	  private String sigu           = null;
	  private String dong           = null;
	  private String ri             = null;
	  private String bungi          = null;
	  private String aptname        = null;
	  private String upd_date       = null;
	  private String address        = null;
	  
	public String getMv_code() {
		return mv_code;
	}
	public void setMv_code(String mv_code) {
		this.mv_code = mv_code;
	}
	public String getMv_title() {
		return mv_title;
	}
	public void setMv_title(String mv_title) {
		this.mv_title = mv_title;
	}
	public int getMv_score() {
		return mv_score;
	}
	public void setMv_score(int mv_score) {
		this.mv_score = mv_score;
	}
	public String getMv_act() {
		return mv_act;
	}
	public void setMv_act(String mv_act) {
		this.mv_act = mv_act;
	}
	public String getMv_story() {
		return mv_story;
	}
	public void setMv_story(String mv_story) {
		this.mv_story = mv_story;
	}
	public String getMv_time() {
		return mv_time;
	}
	public void setMv_time(String mv_time) {
		this.mv_time = mv_time;
	}
	public String getThe_code() {
		return the_code;
	}
	public void setThe_code(String the_code) {
		this.the_code = the_code;
	}
	public String getThe_room() {
		return the_room;
	}
	public void setThe_room(String the_room) {
		this.the_room = the_room;
	}
	public String getMv_code_fk() {
		return mv_code_fk;
	}
	public void setMv_code_fk(String mv_code_fk) {
		this.mv_code_fk = mv_code_fk;
	}
	public String getTime_code() {
		return time_code;
	}
	public void setTime_code(String time_code) {
		this.time_code = time_code;
	}
	public String getTime_start() {
		return time_start;
	}
	public void setTime_start(String time_start) {
		this.time_start = time_start;
	}
	public String getTime_end() {
		return time_end;
	}
	public void setTime_end(String time_end) {
		this.time_end = time_end;
	}
	public String getThe_code_fk() {
		return the_code_fk;
	}
	public void setThe_code_fk(String the_code_fk) {
		this.the_code_fk = the_code_fk;
	}
	public String getSeat_num() {
		return seat_num;
	}
	public void setSeat_num(String seat_num) {
		this.seat_num = seat_num;
	}
	public String getTime_code_fk() {
		return time_code_fk;
	}
	public void setTime_code_fk(String time_code_fk) {
		this.time_code_fk = time_code_fk;
	}
	public String getTicket_code() {
		return ticket_code;
	}
	public void setTicket_code(String ticket_code) {
		this.ticket_code = ticket_code;
	}
	public String getCalendar() {
		return calendar;
	}
	public void setCalendar(String calendar) {
		this.calendar = calendar;
	}
	public String getSeat_num_fk() {
		return seat_num_fk;
	}
	public void setSeat_num_fk(String seat_num_fk) {
		this.seat_num_fk = seat_num_fk;
	}
	public long getTicket_num() {
		return ticket_num;
	}
	public void setTicket_num(long l) {
		this.ticket_num = l;
	}
	public String getTicket_code_fk() {
		return ticket_code_fk;
	}
	public void setTicket_code_fk(String ticket_code_fk) {
		this.ticket_code_fk = ticket_code_fk;
	}
	public String getMem_id_fk() {
		return mem_id_fk;
	}
	public void setMem_id_fk(String mem_id_fk) {
		this.mem_id_fk = mem_id_fk;
	}
	public String getMem_id() {
		return mem_id;
	}
	public void setMem_id(String mem_id) {
		this.mem_id = mem_id;
	}
	public String getMem_pw() {
		return mem_pw;
	}
	public void setMem_pw(String mem_pw) {
		this.mem_pw = mem_pw;
	}
	public String getMem_tel() {
		return mem_tel;
	}
	public void setMem_tel(String mem_tel) {
		this.mem_tel = mem_tel;
	}
	public String getMem_name() {
		return mem_name;
	}
	public void setMem_name(String mem_name) {
		this.mem_name = mem_name;
	}
	public int getUid_no_fk() {
		return uid_no_fk;
	}
	public void setUid_no_fk(int uid_no_fk) {
		this.uid_no_fk = uid_no_fk;
	}
	public int getTicket_num_fk() {
		return ticket_num_fk;
	}
	public void setTicket_num_fk(int ticket_num_fk) {
		this.ticket_num_fk = ticket_num_fk;
	}
	public int getUid_no() {
		return uid_no;
	}
	public void setUid_no(int uid_no) {
		this.uid_no = uid_no;
	}
	public int getZipcode() {
		return zipcode;
	}
	public void setZipcode(int zipcode) {
		this.zipcode = zipcode;
	}
	public String getZdo() {
		return zdo;
	}
	public void setZdo(String zdo) {
		this.zdo = zdo;
	}
	public String getSigu() {
		return sigu;
	}
	public void setSigu(String sigu) {
		this.sigu = sigu;
	}
	public String getDong() {
		return dong;
	}
	public void setDong(String dong) {
		this.dong = dong;
	}
	public String getRi() {
		return ri;
	}
	public void setRi(String ri) {
		this.ri = ri;
	}
	public String getBungi() {
		return bungi;
	}
	public void setBungi(String bungi) {
		this.bungi = bungi;
	}
	public String getAptname() {
		return aptname;
	}
	public void setAptname(String aptname) {
		this.aptname = aptname;
	}
	public String getUpd_date() {
		return upd_date;
	}
	public void setUpd_date(String upd_date) {
		this.upd_date = upd_date;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCal_date() {
		return cal_date;
	}
	public void setCal_date(String cal_date) {
		this.cal_date = cal_date;
	}
}
