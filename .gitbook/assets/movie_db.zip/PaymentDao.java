package movie_db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import movie_project.Payment;

public class PaymentDao {
	DBConnectionMgr dbMgr   = null;
	Connection con 			= null;
	PreparedStatement pstmt = null;
	ResultSet rs            = null;
	
	Payment payment = null;
	
	public PaymentDao() {}

	public PaymentDao(Payment payment) {
		this.payment = payment;
	}
	
	public void insert(long ticket_num, String seat_num, String cal_date, String time_code, String mem_id) {//예매정보  db저장 메서드
		dbMgr = DBConnectionMgr.getInstance();
		con = dbMgr.getConnection();
		StringBuilder sql = new StringBuilder();
			sql.append("INSERT INTO TICKET (TICKET_NUM, SEAT_NUM, CAL_DATE, TIME_CODE, MEM_ID)");
			sql.append(" VALUES (?,?,?,?,?)");
			try {			
					pstmt = con.prepareStatement(sql.toString());
					pstmt.setLong(1, ticket_num);
					pstmt.setString(2, seat_num);
					pstmt.setString(3, cal_date);
					pstmt.setString(4, time_code);
					pstmt.setString(5, mem_id);
					rs = pstmt.executeQuery();	
			} catch (Exception e) {
			System.out.println(e.toString());			
		 }
	}//end of insert

}
