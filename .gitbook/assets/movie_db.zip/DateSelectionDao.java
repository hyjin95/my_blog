package movie_db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import movie_project.DateSelection;
import movie_project.MovieDetail;
import movie_project.MovieSelection;

public class DateSelectionDao {
	DBConnectionMgr dbMgr   = null;
	Connection con 			= null;
	PreparedStatement pstmt = null;
	ResultSet rs            = null;
	
	DateSelection ds = null;
	MovieDetail   md = null;
	public String theater = null;
	public ArrayList<String> time = null;
	public String time_code = null;
	
	public DateSelectionDao() {}//생성사

	public DateSelectionDao(DateSelection ds) {//인스턴스생성자
		this.ds = ds;	}
	
	public DateSelectionDao(MovieDetail md) {//인스턴스 생성자
		this.md = md;	}

	public String theater() {//상영관 select 메서드
		dbMgr = DBConnectionMgr.getInstance();
		con = dbMgr.getConnection();
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT the_room FROM THEATER WHERE mv_code = ?");
		try {			
			pstmt = con.prepareStatement(sql.toString());
			pstmt.setString(1, ds.md.ms.mv_code);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				theater = rs.getString("the_room");	
			}
		} catch (Exception e) {
			System.out.println(e.toString());			
		}	
		return theater;
	}
	
	public void time(String theater) {//상영시간 select 메서드	
		int i;
		dbMgr = DBConnectionMgr.getInstance();
		con = dbMgr.getConnection();
		StringBuilder sql = new StringBuilder();
		MovieVO mVO = new MovieVO();
		time = new ArrayList<>();
		sql.append("SELECT time_start FROM TIME WHERE the_room = ?");
		try {			
			pstmt = con.prepareStatement(sql.toString());
			pstmt.setString(1, theater);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				mVO.setTime_start(rs.getString("time_start"));				
				time.add(mVO.getTime_start());
			} 
		}catch (Exception e) {
			System.out.println(e.toString());			
			}
	}//end of time
	
	public String timeCode(String time, String theater) {//선택 관+시간 -> time_code로 select 메서드
		dbMgr = DBConnectionMgr.getInstance();
		con = dbMgr.getConnection();
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT time_code FROM TIME WHERE time_start = ? AND the_room = ?");
		try {			
			pstmt = con.prepareStatement(sql.toString());
			pstmt.setString(1, time);
			pstmt.setString(2, theater);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				time_code = rs.getString("time_code");	
			}
		} catch (Exception e) {
			System.out.println(e.toString());			
		}
		
		return time_code;
	}//end of timeCode
}
