package movie_db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import movie_project.MovieConfirm;
import movie_project.MovieConfirmSeat;

public class MovieConfirmSeatDao {

	DBConnectionMgr dbMgr = null;
	Connection con 			= null;
	PreparedStatement pstmt = null;
	ResultSet rs 			= null;
	
	MovieConfirmSeat mcs = null;
	
	public MovieConfirmSeatDao(MovieConfirmSeat mcs) {
		this.mcs = mcs;
	}
	
	public void refreshDataSeat(String id, String ticketNum) {
		DBConnectionMgr dbMgr = DBConnectionMgr.getInstance();
		con = dbMgr.getConnection();
		StringBuilder sql = new StringBuilder();
		
		//중복된 값을 제거한 TICKET테이블에서 ticket_num을 조회함. (좌석번호는 포함하고 있지 않음);
		sql.append("SELECT THE.THE_ROOM, TC.SEAT_NUM                                          ");
		sql.append("FROM TICKET TC, TIME TI, MEMBER M, THEATER THE                            ");
		sql.append("WHERE TC.MEM_ID = M.MEM_ID AND TC.TIME_CODE = TI.TIME_CODE AND            ");
		sql.append("TI.THE_ROOM = THE.THE_ROOM AND TC.MEM_ID =:x AND TC.TICKET_NUM =: y       ");
		sql.append("ORDER BY TC.SEAT_NUM ASC                                                  ");
		
		try {
			pstmt = con.prepareStatement(sql.toString());
			pstmt.setNString(1, id);
			pstmt.setLong(2, Long.parseLong(ticketNum));
			rs = pstmt.executeQuery();

			Vector<MovieVO> v = new Vector<>();
			MovieVO mVOS[] = null;
			MovieVO mVO = null;
			while(rs.next()) {
				mVO = new MovieVO();
				mVO.setThe_room(rs.getString("THE_ROOM"));
				mVO.setSeat_num(rs.getString("SEAT_NUM"));
				v.add(mVO);
			}
			mVOS = new MovieVO[v.size()];
			v.copyInto(mVOS);

			for(int x=0; x<mVOS.length; x++) {
				Vector<Object> oneRow = new Vector<>();
				oneRow.add(0,mVOS[x].getThe_room());
				oneRow.add(1,mVOS[x].getSeat_num());
				mcs.dtm_mv.addRow(oneRow);
			}
		} catch (SQLException se) {
			System.out.println(se.toString());
			System.out.println("[[query]]=="+sql.toString());
		} catch (Exception e) {
			System.out.println(e.toString());			
		}
	}
	
}
