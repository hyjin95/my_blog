package movie_db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Vector;

import movie_project.SeatSelection;

public class SeatSelectionDao {
	DBConnectionMgr dbMgr   = null;
	Connection con 			= null;
	PreparedStatement pstmt = null;
	ResultSet rs            = null;	
	
	public ArrayList<String> seatnum = new ArrayList<>();
	public String checkSeat[] = null;
	
	SeatSelection ss = null;

	public SeatSelectionDao() {	}
	
	public SeatSelectionDao(SeatSelection ss) {
		this.ss = ss;
	}
	
	//좌석 중복조회 메서드
	public String[] seat(String cal_date, String time_code) {
		
		System.out.println(cal_date);
		System.out.println(time_code);
		
		dbMgr = DBConnectionMgr.getInstance();
		con = dbMgr.getConnection();
		
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT seat_num FROM TICKET WHERE CAL_DATE =? AND TIME_CODE = ?");
		try {
			pstmt = con.prepareStatement(sql.toString());
			pstmt.setNString(1, cal_date);
			pstmt.setNString(2, time_code);
			rs = pstmt.executeQuery();
			Vector v = new Vector();
			MovieVO mVO = null;
			while(rs.next()) {
				mVO = new MovieVO();
				mVO.setSeat_num(rs.getString("seat_num"));
				v.add(mVO);
			}
			MovieVO[] mVOS = new MovieVO[v.size()];
			v.copyInto(mVOS);
			
			for(int i=0;i<mVOS.length;i++) {
				seatnum.add(mVOS[i].getSeat_num());
			}
			
		} catch (Exception e) {
				System.out.println("Exception : "+e.toString());
			} finally {
				if(pstmt!=null) {
					try {
						pstmt.close();
					}catch(Exception e2) {
						
					}
				}
				if(con!=null) {
					try {
						con.close();
					}catch (Exception e2) {
						
					}
				}
			}//end of finally
		checkSeat = new String[seatnum.size()];
		for(int i=0;i<seatnum.size();i++) {
			checkSeat[i] = seatnum.get(i);
		}
		for(String s : checkSeat) {
			System.out.println(s);
		}
		
		return checkSeat;
	}//end of seat			
}
