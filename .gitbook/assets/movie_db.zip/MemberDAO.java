package movie_db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;

import movie_project.MemberShip;


public class MemberDAO {
		DBConnectionMgr  dbMgr  = null;
		Connection con          = null;
		PreparedStatement pstmt = null;
		ResultSet rs            = null;
		public int result = 0;
		String uid_no = null;
		
		MemberShip memberShip = null;
		public int num = 0;
		
		public MemberDAO() {}
		
		public MemberDAO(MemberShip memberShip) {
			this();
			this.memberShip = memberShip;
		}
		
		public int uid_no(String[] privacy, int privacy_no) {//검색된 우편번호와 db uid_no 매칭 메서드
			dbMgr = DBConnectionMgr.getInstance();
			StringBuilder sql = new StringBuilder();
			con = dbMgr.getConnection();
			sql.append("SELECT uid_no AS num FROM zdo WHERE zipcode=? AND address=?");
			try {
				pstmt = con.prepareStatement(sql.toString());
				pstmt.setInt(1, privacy_no);
				pstmt.setNString(2, privacy[7]);
				rs = pstmt.executeQuery();
				
				while(rs.next()) {
					num = rs.getInt("num");					
				}
			}catch (Exception e) {
				System.out.println("Exceptioin : "+e.toString());
			}					
			return num;
		}//end of uid_no
		
		public void setRegister(String[] privacy) {//등록 메서드
			dbMgr = DBConnectionMgr.getInstance();
			con = dbMgr.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("INSERT INTO MEMBER ");
			sql.append(" VALUES ('" + privacy[0] + "', '" + privacy[1] + "', '" + privacy[2] + "', '"
									+ privacy[3] + "', '" + privacy[4] + "', '" + privacy[5] + "', '"
									+ privacy[6] + "', " + num + ")");
			try {//인터넷이 끊겼을 경우 에러 발생
				//전령 객체 메모리에 로딩
				pstmt = con.prepareStatement(sql.toString());
				//전령객체를 로딩할 때 파라미터로 select문을 전달했다.
				//그 문을 처리해 주세요. 만일 insert할때는 executeUpdate호출함.
				pstmt.executeUpdate();
				} catch (Exception e) {
				System.out.println("Exceptioin : "+e.toString());
			}			
		}//end of setRegister
		
		public int getMemID(String id) {//아이디 중복체크 메서드
			dbMgr = DBConnectionMgr.getInstance();			
			StringBuilder sql = new StringBuilder();			
			con = dbMgr.getConnection();
			sql.append("SELECT NVL((SELECT 1 FROM MEMBER WHERE mem_id =?),0)res FROM dual");
			try {
				pstmt = con.prepareStatement(sql.toString());
				pstmt.setNString(1, id);
				rs = pstmt.executeQuery();
				
				while(rs.next()) {
					result = rs.getInt("res");					
				}
			} catch (Exception e) {
					System.out.println("Exception : "+e.toString());
				} finally {
					if(pstmt!=null) {
						try {
							pstmt.close();
						}catch(Exception e2) {
							
						}
					}
					if(con!=null) {
						try {
							con.close();
						}catch (Exception e2) {
							
						}
					}
				} //end of finally				
			return result; //0이면 사용가능, 1이면 사용중
		}//end of getMemID
}

