package baseballgame;

import baseballgame.BaseBallGameView;

public class BaseBallGameMain {

	public static void main(String[] args) {
		BaseBallGameView bbgv = new BaseBallGameView();
		bbgv.initDisplay();
		bbgv.bgl.ranCom();	
	

	}

}