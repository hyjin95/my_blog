package baseballgame;

import java.awt.Color;

import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JTextArea;

public class BaseBallGameCRUD extends JDialog {
	JTextArea bjta_display = null;
	
	public void initDisplay() {
		bjta_display = new JTextArea();
		add(bjta_display);
		bjta_display.setLineWrap(true);
		bjta_display.setBackground(new Color(255,220,239));//배경색
		bjta_display.setForeground(new Color(53,48,201));//글자색
		this.setVisible(false);
	}
	/*
	 * public static void main(String args[]) { new BookCRUD().initDisplay(); }
	 */
}
