package baseballgame;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class BaseBallGameEvent implements ActionListener {
	BaseBallGameView bmv = null;
	

	public BaseBallGameEvent(BaseBallGameView bmg) {
		this.bmv = bmg;
	}	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		BaseBallGameCRUD bcrud = new BaseBallGameCRUD();
		String label = e.getActionCommand();//입력 or수정 or상세보기가 들어옴
		//System.out.println("lable = "+label);//단위테스트
		Object obj = e.getSource();
		
		if("나가기".equals(label)) {
			System.exit(0);
		}
		
		else if("새게임".equals(label)) {//글자타입 비교는 .equals
			bmv.bgl.cnt = 0;
			bmv.bgl.ranCom();
			bmv.jta_display.setText("");
			bmv.jtf_user.setText("");
			bmv.jtf_user.requestFocus();
		}
		
		else if("정답".equals(label)) {
			bmv.jta_display.append("정답은"+bmv.bgl.com[0]+bmv.bgl.com[1]+bmv.bgl.com[2]+"\n");
		}		
		else if("지우기".equals(label)) {
			
		}		
		else if(obj==bmv.jmi_detail) {//야구숫자게임이란 대응이벤트
			bcrud.initDisplay();
			bcrud.setTitle("야구숫자게임이란?");
			bcrud.bjta_display.append("야구숫자게임은 랜덤한 세 숫자를 맞추는 게임입니다. "
					                   +"\n" +"숫자와 자리를 맞추면 Strike, 하나만 맞추면 Ball이 카운트됩니다.");
			bcrud.setSize(200, 300);
			bcrud.setVisible(true);
			
		}
		else if(obj==bmv.jmi_create) {//만든사람들 대응이벤트
			bcrud.initDisplay();
			bcrud.bjta_display.append("KOSMO69기"+"\n"+"오상기"+"\n"+"윤주연"+"\n"+"신민경"+"\n"+"한영진");
			bcrud.setTitle("제작자");
			bcrud.setSize(200, 300);
			bcrud.setVisible(true);
			
		}
		else if(e.getSource()==bmv.jtf_user) {
			bmv.jta_display.append(++bmv.bgl.cnt+"회차. "+bmv.jtf_user.getText()+" : "+bmv.bgl.account(bmv.jtf_user.getText())+"\n");
			bmv.jtf_user.setText("");
		}
			
	  }//end of actionPerformed
}