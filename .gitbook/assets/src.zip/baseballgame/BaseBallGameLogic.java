package baseballgame;

 import javax.swing.JOptionPane;

public class BaseBallGameLogic {
	
    int my[]  = new int[3];
    int com[] = new int[3];
    int cnt = 0;
    
    public void ranCom() {
        com[0] =(int)(Math.random()*10);
        do {
           com[1] =(int)(Math.random()*10);         
        }while(com[0]==com[1]);
        do {
           com[2] =(int)(Math.random()*10);         
        }while(com[0]==com[2] || com[1]==com[2]);
     }
     public String account(String user) {
       if(user.length()!=3) {
          return "세자리 숫자를 입력하세요.";
       }
       //사용자가 jtf_user에 입력한 숫자는 보기에는 숫자 처럼 보여도 알맹이는 문자열로 
      //인식을 합니다. 그래서 형전환을 한 후 my[]배열에 담아야 함니다.
       //문자열 "256"을 숫자로 담을 변수 선언
      int temp    = 0;
       int strike = 0;//힌트로 사용될 스트라이크를 담을 변수 선언
      int ball    = 0;//볼을 담을 변수 선언
      //strike와ball을 지역변수로 해야 하는건 매 회차 마다 값이 변해야 하기 때문이다.
       try {
          temp = Integer.parseInt(user);
       } catch (NumberFormatException e) {
          return "숫자만 입력하세요.";
       }
       
       my[0] = temp/100;
       my[1] = (temp%100)/10;
       my[2] = temp%10;
       JOptionPane.showMessageDialog(null, my[0]+""+my[1]+""+my[2]);
       for(int i=0;i<3;i++) {
          for(int j=0;j<3;j++) {
             if(my[i]==com[j]) {//너 안에 내가 가진 숫자가 있는거야?
                if(i==j)//그러면 자리까지도 일치하는 거니?
                   strike++;
                else ball++;
             }
          }
       }
       if(strike==3) {
          return "축하합니다. 정답입니다!!!";
       }
       return strike+"스  "+ball+"볼";
    }
  	
}    
    