package ocjp.basic;
import javax.swing.JButton;
//상속관계에서 자식이 변수와 메소드 갯수가 더 많다.
import javax.swing.JFrame;

//A is a B ->B가 아빠 : sonata is a car
//할아버지(원본메서드) 아빠(overlodaing된, 개선된 메서드)
public class JButtonArray extends JFrame{
	//10번과 11번의 차이점
	
	String labels[] = {"조회", "입력", "삭제"};//선언, 생성, 초기화까지 완료
	JButton jbtns[] = new JButton[3];//선언, 생성만 했다. 초기화는 아직
	
	//디폴트 생성자 선언해보기
	//디폴트 생성자의 역할 : 
	public JButtonArray(String title) {
		this.setTitle(title);
		initDisplay();//생성자에서의 메서드 호출
	}
	
	public JButtonArray(int height) {
		this.setSize(700, height);
		initDisplay();
	}

	public void initDisplay() {
		this.setSize(400, 300);//나는 어디에 선언된 메서드인가요? 아빠를 찾아주세요 = JFrame, this=나=JButtonArray
		this.setVisible(true);//메서드 호출시 파라미터의 갯수가 같나요?
	}	

	public static void main(String[] args) {
		new JButtonArray("생성자에 대해서..");//파라미터가 없는 생성자를 호출하는 문장,
		new JButtonArray(100);
	}
}
