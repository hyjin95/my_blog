package ocjp.basic;

public class Q12 {
	int x = 0;

	public static void main(String[] args) {
			 int x = 5;  //main에서 선언된 지역변수
			 
			 //Q12 q = null;//선언만 되었다. 이 주소번지를 사용하면 NullPointException으로 Runtime에러가 발생
			 Q12 q = new Q12();
			 q.doStuff(x);
			 System.out.println(" main x = "+ x);//5
			 System.out.println(" main x = "+ q.x);//2 24번 this=q
			 q.doStuff(q);//4
	   }//end of main
	
	   void doStuff(Q12 q) {//참조형 변수를 파라미터로 갖는 메서드//object타입 파라미터
		   System.out.println("doStuff q = "+ (q.x+2));//2 q.x=0
	   }
			
	   void doStuff(int x) {//int타입 파라미터
		  System.out.println(" doStuff x = "+ x++);//5
		  System.out.println(" doStuff x = "+ this.x++);//0, x->1
		  System.out.println(" doStuff x = "+ ++this.x);//x->2
		  System.out.println("===============================");
	   }//end of doStuff
		
}//end of Q12

/* main
 * q.doStuff("0"); 
 * 
 * void doStuff(String s) { //string타입 파라미터
 * s = "안녕";
 * System.out.println(" String s = "+s); }
 */