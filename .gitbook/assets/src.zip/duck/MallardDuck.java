package duck;

/*
 * FlyBehavior는 인터페이스이다.
 * 메서드 선언만 되어있고 구현할수 있는 바디가 없는 상태 이므로 
 * 반드시 구현체 클래스가 있어야 활용할 수 있다.
 * 구현체 클래스가 implements를 갖는다.
 * 이 세상에 날수 있는 동물, 사물들이 많이 있다.
 * 사물이 갖는 공통분모를 찾기위해 인터페이스를 설계한다.
 * 단독으로는 인스턴스화 할 수 없다.->implements이용
 * 추상메서드를 갖고 있기때문에 결정되어있지않아서 쓸수 없기때문이다.
 */
public class MallardDuck extends Duck {//Duck추상클래스를 아빠로 갖는다.//implements FlyBehavior {//청둥오리는 인터페이스가 필요없다. 구현체 클래스를 가져올거니까.
	
	public MallardDuck() {
		//fb = new FlyBehavior();//호출 불가하다. 기능이 있는 클래스가 아니므로
		fb = new FlyWithWings();//구현체 클래스를 호출
		fb.fly();
		fb = new FlyNoWay();
		fb.fly();
	}

	@Override
	public void swimming() {
		System.out.println("나는 물위에 뜹니다.");		
	}
}
