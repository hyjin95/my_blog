package duck;

public class WoodDuck extends Duck {
	//FlyBehavior fb = null;
	
	public WoodDuck() {
		fb = new FlyNoWay();
		fb.fly();
	}

	@Override
	public void swimming() {
		System.out.println("나는 물에 가라앉습니다.");		
	}
}
