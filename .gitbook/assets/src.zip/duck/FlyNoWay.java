package duck;

//구현체 클래스2
public class FlyNoWay implements FlyBehavior {

	@Override
	public void fly() {
		System.out.println("나는 날지 못합니다.");
		
	}

	@Override
	public int methodA() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int methodA(int i) {
		// TODO Auto-generated method stub
		return 0;
	}

}
