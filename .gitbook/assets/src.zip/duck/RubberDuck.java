package duck;

public class RubberDuck extends Duck{
	//FlyBehavior fb = null;
	
	public RubberDuck() {
		fb = new FlyNoWay();
		fb.fly();
	}

	@Override
	public void swimming() {
		// TODO Auto-generated method stub		
	}
}
