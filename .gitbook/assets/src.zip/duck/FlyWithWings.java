package duck;

//인터페이스로 FlyBehavior을 받아오면 꼭 갖고있어야하는 메서드가 정해진다.=필수메서드
//인터페이스의 메서드를 구현해주는 구현체 클래스2
public class FlyWithWings implements FlyBehavior {

	@Override
	public void fly() {
		System.out.println("나는 날고 있어요.");
		
	}

	@Override
	public int methodA() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int methodA(int i) {
		// TODO Auto-generated method stub
		return 0;
	}

}
