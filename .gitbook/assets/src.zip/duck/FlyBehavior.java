package duck;
/*
 * 인터페이스는 메서드 선언만 할 수 있다. =구현할 수 있는 바디가 없다.(반복문for if 등 , 출력문print 등 불가능)
 * 밑의 세 메서드들은 클래스가 정해지지 않았으므로 결정할 수 없다.
 * FlayBehavior의 구현체 클래스 = FlyWithWings, FlyNoWay
 */
public interface FlyBehavior {
	//public void fly() {}//{}==구현을 한다, 바디가 있다. 인터페이스에서는 오류
	public void fly();//바디가 없다 = 아직 결정할 수 없다.
	public int methodA();//리턴타입과 파라미터만 존재한다.
	public int methodA(int i);

}
