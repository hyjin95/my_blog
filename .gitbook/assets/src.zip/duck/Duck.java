package duck;

/*
*추상클래스 : 단독으로는 인스턴스화 할 수 없다.
*반드시 구현메서드가 있어야한다.
*그러나 일반 메서드도 가질 수 있다.
*그래서 인터페이스가 더 추상적이다.
*/
public abstract class Duck {//abstract = 추상클래스
	//추상클래스도 전변을 가질 수 있다.
	FlyBehavior fb = null;//선언
	
	public void methodA() {
		fb.fly();
	}
	//{ }가 있는, 바디가 있는 메서드가 일반 메서드이다.
	public void display() {
		System.out.println("나는 오리 입니다.");
	}
	
	//swimming 은 추상메서드이다
	//인터페이스 에서는 abstract를 생략할 수 있지만(모두 다 추상메소드만 오므로)
	//그런데 추상클래스는 일반 메서드도 같이 공존하므로 구분할 수 있어야한다.
	//JVM이 인식하는 추상메서드는 abstract를 붙여야한다.
	public abstract void swimming();

}
