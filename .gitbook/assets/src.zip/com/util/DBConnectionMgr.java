package com.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class DBConnectionMgr {
	
	public static DBConnectionMgr dbmgr = null;//DBConnectionMGR객체를 싱글톤으로 하기=공통코드
	
	public static final String _DRIVER = "oracle.jdbc.driver.OracleDriver";
	public static final String _URL = "jdbc:oracle:thin:@192.168.0.187:1521:orcl11";
	public static String _USER = "scott";
	public static String _PW   = "tiger";
	Connection con = null;
	
	//싱클톤 패턴에 대해 생각해보기
	public static DBConnectionMgr getInstance() {//static이 붙으면 바로 사용가능하다.
		if(dbmgr==null) {//인스턴스화안되어있으면 넘긴다.
			dbmgr = new DBConnectionMgr();
		}
		return dbmgr;//return object타입
	}
	
	//
	public Connection getConnection() {//Connection import, 참조형이다, 연결
		try {//예외처리를 했다. 실행시에 에러발생할 가능성이있는 코드는 try-catch로 예외처리한다.
			Class.forName(_DRIVER);///////////////////////////////드라이버 클래스 이름을 찾는 호출
			con = DriverManager.getConnection(_URL, _USER, _PW);//연결 호출 == 인스턴스화
		} catch (ClassNotFoundException ce) {/////////////////////클래스 이름을 찾을수 없는 오류 예외처리
			System.out.println("드라이버 클래스를 찾을 수 없습니다.");
		} catch (Exception e) {///////////////////////////////////con, 연결 오류에 대한 예외처리
			System.out.println("연결 실패 "+e.toString());
		}
		//return null;//NullPointerException 오류
		return con;//return 반환타입이 인터페이스이다.
	}
	//서버의 입장에서는 사용한 자원은 반드시 반납해야한다.
	//생성한 역순으로 한다.
	//순서 : Connection - PreparedStatment - ResultSet 
	public void freeConnection(Connection con
								, PreparedStatement pstmt
								, ResultSet rs) {
		if(rs!=null) {
			try {
				rs.close();
			}catch (Exception e) {
				System.out.println("Exception ---> "+e.toString());
			}
		}//end of if
		if(pstmt!=null) {
			try {
				pstmt.close();
			}catch (Exception e) {
				System.out.println("Exception ---> "+e.toString());
			}
		}//end of if
		if(con!=null) {
			try {
				con.close();
			}catch (Exception e) {
				System.out.println("Exception ---> "+e.toString());			
			}
		}//end of if		
	}//end of freeConnection
}//class
		

