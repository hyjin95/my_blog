package design.book;
//main함수는 필요없다, 버튼이 눌러졋을때 bookManager에서 호출될것이므로

import javax.swing.JDialog;

public class BookCURD extends JDialog {
	
	public void initDisplay() {
		//this.setTitle("입력|수정|상세보기");외부에서 값이 바뀌므로 이 클래스에선 필요없다.
		//this.setSize(500, 400);//외부에서 값이 정해지므로 이 클래스안에는 필요없다.
		//this.setVisible(false);
	}
	/*
	 * public static void main(String args[]) { new BookCURD().initDisplay();//단위테스트
	 * }
	 */

}
