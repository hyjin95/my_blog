package design.book;
import java.awt.event.ActionEvent;
//main필요없이 interface에 actionlistener추가한다.
import java.awt.event.ActionListener;

public class BookManagerEventHandler implements ActionListener {
	BookManager bm = null;//주의사항 : new금지. new는 복제본, 변하지 않은 원본을 가져와야한다.
	
	public BookManagerEventHandler(BookManager bmg) {//BookManager
		this.bm = bmg;//bm이 null로 되어잇고 초기화를 안하면 performed메서드에서 bm값이 비어있기때문에 오류발생한
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		String label = e.getActionCommand();//입력 or수정 or상세보기가 들어옴
		System.out.println("lable = "+label);//단위테스트, 잘 가져오는지
		
		if("입력".equals(label)) {//글자타입 비교는 .equals
			System.out.println("입력하시겠습니까?");//단위테스트
			bm.bookCURD.setTitle(label);//Main.java 12번 참고하기
			bm.bookCURD.setSize(500, 400);
			bm.bookCURD.setVisible(true);
		}
		else if("수정".equals(label)) {
			System.out.println("수정하실건가요?");
			bm.bookCURD.setTitle(label);
			bm.bookCURD.setSize(500, 400);
			bm.bookCURD.setVisible(true);
		}
		else if("상세보기".equals(label)) {
			System.out.println("상세정보를 보여드릴까요?");
			bm.bookCURD.setTitle(label);
			bm.bookCURD.setSize(500, 400);
			bm.bookCURD.setVisible(true);
		}
		else if("나가기".equals(label)) {
			System.exit(0);
		}
			
	  }//end of actionPerformed
}


