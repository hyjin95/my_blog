package design.book;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JSeparator;

//public class BookManager extends JFrame implements ActionListener{
public class BookManager extends JFrame {
	JMenuBar  jmb      = new JMenuBar();
	JMenu     jm_edit  = new JMenu("Edit");
	JMenuItem jmi_ins  = new JMenuItem("입력");
	JMenuItem jmi_upd  = new JMenuItem("수정");
	JMenuItem jmi_det  = new JMenuItem("상세보기");
	JSeparator js1     = new JSeparator();//줄 긋는 용도
	JMenuItem jmi_exit = new JMenuItem("나가기");
	//생성자는 디폴트생성자를 제외하고는 무조건 개발자가 추가로 작성해야한다.
	//eventhandler에 bookmanager의 주소는 담는 생성자가 필요하다.
	
	BookManagerEventHandler handler = new BookManagerEventHandler(this);//다른 메서드에서 쓸수잇게 전역위치에서 인스턴스
	
	//this : 이벤트 처리를 꺼내놧다. 이벤트를 감지해야하는데 메뉴item이 bookmanager클래스에 있기때문에 생성자 안에 this=bookmanager가들어가야한다.
	BookCURD bookCURD = new BookCURD();
	
	public BookManager() {//생성자 - 초기화용
		
	}
	
	public void initDisplay() {//화면그리기
		//이벤트 소스와 이벤트 처리 핸들러 클래스는 매칭하기
		jmi_ins.addActionListener(handler);//this=BookManager 이 클래스 안에 actionPerformed가 있어야한다.그래야 구현이된다.
		jmi_upd.addActionListener(handler);
		jmi_det.addActionListener(handler);
		jmi_exit.addActionListener(handler);
		
		jm_edit.add(jmi_ins);
		jm_edit.add(jmi_upd);
		jm_edit.add(jmi_det);
		jm_edit.add(js1);
		jm_edit.add(jmi_exit);
		jmb.add(jm_edit);
		this.setJMenuBar(jmb);//superclass가 JFrame이므로 import및 호출이 없이 this로 하면됨.
		
		this.setTitle("도서관리 시스템 Ver1.0");
		this.setSize(700, 450);
		this.setVisible(true);	
	}

	public static void main(String[] args) {//최대한 간소화
		JFrame.setDefaultLookAndFeelDecorated(true);
		BookManager bm = new BookManager();
		bm.initDisplay();
		

	}
   //어노테이션-오버라이드=부모가 선언한 메서드를 재정의
//	@Override
//	public void actionPerformed(ActionEvent e) {//부모클래스에서 선언된 메소드의 파라미터, 리턴타입을 수정하면안된다.
//		//이벤트 연결처리
//		
//	}

}
