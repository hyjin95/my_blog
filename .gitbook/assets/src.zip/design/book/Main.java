package design.book;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;

class Sub extends JDialog{
	Main m = null;//new하면 복제본이다.
	
	public Sub(Main m) {//부모가 갖고있는 버튼을 Sub클래스에서 사용해보기
		this.m = m;
		m.getButton().setText("가입");//메서드 뒤에 온점. 두번 접근하기
		this.add("North", m.getButton());//메서드를 통한 버튼 만들기
		this.setTitle("Sub화면 입니다.");
		this.setSize(300, 200);
		this.setVisible(true);
	}	
}

public class Main extends JFrame {
	JButton jbtn_add = new JButton("등록");
	
	Main m = null;
	public Main getInstance() {
		if(m!=null) {//null체크랄 해서 복사본이 만들어지는것, m이 두세번 생성되는것을 막는다.
			m = new Main();//비교하고 사용하므로 단 하나만 남는다. = 싱클톤
		}
		return m;
	}
	
	public JButton getButton() {//get메서드
		return jbtn_add;
	}

	public static void main(String[] args) {
		Main m = new Main();
		Sub sub = new Sub(m);

	}

}
