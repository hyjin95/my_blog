package book.ch2;

public class Sonata_Teacher {
	int speed = 0; 
	void speedUp() {
		speed = (speed + 1); 
	}
	void speedDown( ) {
		speed = (speed - 1);
	} 
	//메인 스레드(Thread)-우선순위1번
	public static void main(String[] args) {
		Sonata_Teacher mycar = new Sonata_Teacher();
		mycar.speedUp();
		Sonata_Teacher hercar = new Sonata_Teacher();
		hercar.speedUp();
		
		System.out.println(hercar.speed); //hercar의 현재 속도 (기본값=0, Up상태 호출, 결과=1)
	    System.out.println();
	}//end of main
}
