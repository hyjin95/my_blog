package book.ch2;
//변수와 메소드 구분하기
public class Method1_1 {
	int i =3;
	public static void main(String[] args) {//args=배열
		Method1 m1 = new Method1();//클래스의 인스턴스화(풍선만들기)
		m1.methodA();//클래스 안에 있는 메소드 호출
		System.out.println("main 호출 성공");
	}//main메소드가 없으면 이 클래스는 실행되지않는다. methodA라는 명령어만 가지고 있을뿐이다.

	void methodA() { //메소드를 선언
		System.out.println("methodA 호출 성공");//실행문
	}//end of methodA-다시 나를 부른곳으로 돌아감
	/* 실행 순서 11-12-13-5-6-7-14 항상 메인 메소드 부터 실행된다.
	 * 
	*/ 	

}
