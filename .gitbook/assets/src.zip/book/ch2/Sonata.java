package book.ch2;

public class Sonata {
	public int speed = 0; //speed 초기화
	void speedUp() {
		int speed = speed + 1; 		
	}
	void speedDown( ) {
		int speed = speed - 1;		
	} 
	//메인 메소드 = 메인 스레드(Thread) - 자바에서 제공되는 클래스, 우선순위 1번
	public static void main(String[] args) {
		Sonata mycar = new Sonata();
		Sonata hercar = new Sonata();
		mycar.speedUp();
	    hercar.speedDown();
	    
	    System.out.println(mycar.speedUp);
	    System.out.println(hercar.speedDown);
	}

}
