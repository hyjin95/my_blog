package book.ch2;

public class Quiz3 {

	public static void main(String[] args) {
		System.out.println(1+"2");//12
		System.out.println("1"+2);//12
		System.out.println(1+2);//3
		System.out.println("1"+"2");//12		
		//문자열 더하기는 문자열이다.
		//문자열+숫자=문자열 (문자로 본다.)
		//숫자+숫자=숫자
		//숫자+문자열=문자열
		//숫자 더하기 숫자는 숫자이다.
				

	}

}
