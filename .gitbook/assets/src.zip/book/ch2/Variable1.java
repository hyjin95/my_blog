package book.ch2;
//에러에는 두가지가 있다.
//문법에러
//런타임에러(실행에러:문법에러는 없다.)
public class Variable1 {

	public static void main(String[] args) {
		int i = 3;
				System.out.println(3);
				System.out.println(i);//여기서  출력되는 3과 3은 다르다. 3은 그냥 숫자고 i는 변수=값 이다.
				String name = "KOSMO";
				name="IT사관학교";//초기화
				System.out.println("KOSMO");
				System.out.println("KOSMO");
				System.out.println("KOSMO");
				System.out.println("====================");
				System.out.println(name);
				System.out.println(name);
				System.out.println(name);//변수를 사용하는 이유 = 일괄처리
	}

}
