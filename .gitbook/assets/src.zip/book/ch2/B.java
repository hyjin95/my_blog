package book.ch2;
/*
 * 하나의 클래스 안에 여러개의 메소드를 선언할 수 있다.
 * 내안의 메소드는 인스턴스화 없이도 호출할 수 있다.
 * 단 내안에 있는 메소드일지라도 static영역에서 호출할땐 반드시 인스턴스화 해야한다.
 */
class B1{
	void go() {//메소드1
		//home();//B1클래스에서는 B클래스가 소유한 home메소드를 불러올 수 없다.
		//해결 : 소유하고 있는 클래스의 이름으로 인스턴스화 하면 된다.
		B b = new B();//내 안에 없는 메소드를 사용하려면 인스턴스화를 하면 된다.
		b.home();
		System.out.println("go호출 성공");
		
	}
	
}
public class B {
	void home() {//메소드2
		System.out.println("home호출 성공");
	}
	void come( ) {//메소드3
		
	}

	public static void main(String[] args) {
		B b = new B();
		B1 b1 = new B1();
		b1.go();
		b.home();
		b.come();
		
		int val = Integer.parseInt("10");
		double dval = Double.parseDouble("3.14");
		String sval = "10";
		int val2 = Integer.parseInt(sval);
		
		System.out.println(val);//문자를 숫자로 출력
		System.out.println(dval);//문자를 숫자로 출력
		System.out.println(sval);//문자출력
		System.out.println(val2);//문자를 숫자로 출력

	}

}
