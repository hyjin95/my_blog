package book.ch2;

import javax.swing.JOptionPane;

//non-static변수나 메소드는  static영역에서 사용할 수 없다. <인스턴스화필요
public class Addition2 {

	public static void main(String[] args) {
		
		String firstNumber = JOptionPane.showInputDialog("계산할 숫자 입력하세요.");
		
		int number1=Integer.parseInt(firstNumber);
		int tot = number1*number1*number1;
		
		System.out.println(tot);
		JOptionPane.showMessageDialog(null, "The tot is"+tot,"처리 결과", JOptionPane.INFORMATION_MESSAGE);

	}

}
