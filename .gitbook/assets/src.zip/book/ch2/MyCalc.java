package book.ch2;

import javax.swing.JFrame;
//이 프로그램은 전자계산기를 구현한 것입니다.
//사직연산이 가능합니다.
public class MyCalc {
	public static void main(String[] args) {
		JFrame jf = new JFrame();//인스턴스화 jf=주소
		int width = 300;
		width = 600;
		int height = 400;
		jf.setSize(width, height);//width, height가 정수이기 때문에 setSize int를 사용
		String title = "전자 계산기";
		title = "카카오톡";
		jf.setTitle(title);
		boolean isOK = true;
	    jf.setVisible(isOK);//보이게한다=true 보이지않게한다=false
	}/////////////end of main
}////////////////end of MyCalc
