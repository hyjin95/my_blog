package book.ch2;

public class Quiz2 {

	public static void main(String[] args) {
		int a=1;
		int b=2;
		int c=3;
		int tot=a+b+c;
		System.out.println(a+"+"+b+"+"+c+"="+tot);//1+2+3=6
		System.out.println(a+"+"+b+"+"+c+"="+a+b+c);//1+2+3=123
		System.out.println(a+"+"+b+"+"+c+"="+(a+b+c));//1+2+3=6
		System.out.println("a+b*c===>"+(a+b*c));//a+b*c===>7
	    System.out.println("(a+b)*c===>"+((a+b)*c));//(a+b)*c===>9
		// TODO Auto-generated method stub

	}

}
