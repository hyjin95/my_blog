package book.ch2;

import javax.swing.JOptionPane;

public class D {

	public static void main(String[] args) {
		String s = JOptionPane.showInputDialog("지구에서의 몸무게를 입력하시오");
		System.out.println("지구에서의 몸무게 : "+s+"kg");
		
		double num1 = Double.parseDouble(s);
		
		double moon = num1*0.17;
		
		System.out.println("달에서의 몸무게 : "+moon+"kg");				


	}

}
