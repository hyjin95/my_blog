package book.ch2;
//주석은 실행되지 않습니다.
//주석에는 업무에 대한 내용과 담당자 이름, 버전정보 등 회사 고유 업무내용이 포함됩니다.
//따라서 배포할땐 XXX.class만 배표해야한다.
public class Variable2 {
	//전역변수의 위치. 지금 이 클래슨에 전역변수는 없다.
	int i;//전변생성, 기본값으로 0을 갖는다.
	/**********************************************
	 * 로그인 버튼을 누르면 이 메소드를 호출합니다.
	 * @param id - 사용자가 입력하는 값을 받는다.
	 * @param pw - 사용자가 입력하는 비번을 받는다.
	 * @return - id와 pw를 비교해서 모두 일치하면(교집합)
	 * 학습목표
	 * 나는 메소드의 파라미터 자리에 선언되는 변수가 무엇인지 
	 * 설명할 수 있다.
	 * 내 안에 있는 메소드라 하더라도 메인메소드에서 호출 하려면
	 * 인스턴스화한 후 인스턴스변수.login("apple","123"); : 메소드호출
	 * 회원가입 - 등록 - 오라클
	 * 로그인 - 조회(찾기)
	 **********************************************/
	String login(String id, String pw) {
		return "홍길동님 환영합니다.";
	}
	void methodA(int i){//i는 지변. methodA안에서만 접근 가능하다.
		System.out.println(i);//i는 지역변수
		//내 안에 있는 메소드는 인스턴스화 없이 호출 할 수 있다.
		login("haha","123");//메소드 호출
	}
	void methodB() {
		System.out.println(i);
	}
	
	public static void main(String[] args) {
		//Variable1 v2 = new Variable1();//Variable1에는 login메소드가 없다.
		Variable2 v2 = new Variable2();
		v2.login("haha","123");//메인메소드에서는 인스턴스화 필수
		v2.methodA(5);
		v2.methodB();
		System.out.println("전역변수 i: "+v2.i);

	}

}
