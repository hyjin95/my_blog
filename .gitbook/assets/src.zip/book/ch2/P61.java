package book.ch2;

public class P61 {
	/*
	 * 변수 앞 : 상수
	 * 메소드 앞 : 메소드 오버라이딩을 하지못한다.
	 * 클래스 앞 : 자녀 클래스를 가질 수 없다.  
	 * 
	 */

	public static void main(String[] args) {
		int i = 5;
		i = 7;
		final double PI = 3.14;//PI는 상수로 고정된 변수로, 다른값으로 초기화하면 실행되지않는다.
		final String _URL = "192.168.0.187";
		System.out.println("i는"+i);
		System.out.println("PI는"+PI);

	}

}
