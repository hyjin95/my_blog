package book.ch2;
//가상머신과의 연결고리가 끊어 졌으므로 다시 처음부터 실행할 수 없다.
public class Tivoli {

	public static void main(String[] args) {
		int first=1;
		int second=2;
		//파라미터 두 개짜리 메소드가 정의되어 있지 않아서 컴파일 에러가 발생
		//이 상태에서는 실행해 볼 수가 없다. 실행하려 해도 Tivoli.class파일이 만들어지지 않으므로
		System.out.println(first+second);
		//println(first,second)이면, println메소드에는 파라미터 두개를 정의하고 있지 않거나 타입이 같지않기때문에 실행되지 않는다.
		//printhln메소드는 JDK에 내장되어있는 메소드이다.
		System.out.print(5);
		
	}

}
