package book.ch2;
/*
 * 대입연산자 오른쪽에 있는 값을 왼쪽에 대입한다.
 * 주의사항
 * 작은 값을 더 큰 타입에 대입하는 건 합법.
 * 그러나 큰 타입을 작은 타입의 변수에 대입하는 건 불법이다.
 */

public class E {

	public static void main(String[] args) {
		int i = 1;
		double d = i;
		//i = d;//double의 범위가  int보다 넓으므로 성립되지않는다.
		i = (int)d;//강제 형전환, 왼쪽에 대입하므로 왼쪽 타입으로 강제형전환 하도록 한다.
		d = i;
		float f = 1.5f;
		i = (int)f;
		float f1 = (float)d;
		
		System.out.println(i);//1
		System.out.println(f1);//1.0

	}

}
