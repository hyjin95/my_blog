package book.ch3;

public class P74 {

	public static void main(String[] args) {
		int num = 2;
		int val = 0;
		
		val = ++num;	
		System.out.println(val);//3
		System.out.println(num);//3
		
		val = num++;
		System.out.println(val);//3
		System.out.println(num);//4
		
		val = --num;
		System.out.println(val);//3
		System.out.println(num);//3
		
		val = num--;
		System.out.println(val);//3
		System.out.println(num);//2
				
	}

}
