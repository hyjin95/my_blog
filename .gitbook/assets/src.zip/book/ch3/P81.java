package book.ch3;

public class P81 {

	public static void main(String[] args) {
		//조건연산자=삼항연산자 조건식? 결과1:결과2; 참이면 결과1 거짓이면 결과2
		String account = (45<47) ? "참":"거짓";
		System.out.println(account);

	}

}
