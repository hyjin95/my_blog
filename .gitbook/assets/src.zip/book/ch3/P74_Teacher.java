package book.ch3;

public class P74_Teacher {

	public static void main(String[] args) {
		int x = 2;
		int y = 1;
		y = ++x; //x=3 , y=3
		System.out.println("x="+x+", y="+y);
		
		x = 5;
		y = x--;//x=4, y=5
		System.out.println("x="+x+", y="+y);
		
		
		x = y;//x=5, y=5
		y = x + y;//y=10
		System.out.println("x="+x+", y="+y);
		
		x = 0;
		y = 1;
		x = --y;//x=0, y=0
		y = ++y;//y=1
		System.out.println("x="+x+", y="+y);
		x = x - y;//x=-1, y=-1
		y = x ++;//x=0, y=-1
		System.out.println("x="+x+", y="+y);
		x = x - y++;//x=1, y=2
		y = --x;//x=0, y=0
		System.out.println("x="+x+", y="+y);
	}

}
