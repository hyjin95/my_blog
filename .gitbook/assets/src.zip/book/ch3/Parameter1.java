package book.ch3;

public class Parameter1 {
	//Parameter1 p2 = new Parameter1();//p2는 전변이다.
	//값에 의한 호출입니다.
	//그래서 지변 x에는 10이 담기고, 지변y 에는 20이 담긴다.
	void methodA(int x, int y) {//x=10. y=20
		System.out.println("methodA호출 성공");
		//p2.methodA(1,2);
		System.out.println(x+y);
		
	}
	//메소드 선언할때 반환 타입을 결정할 수 있다.
	//리턴 타입이 있는 경우 실행문 마지막에 반드시 return이라는 예약어를
	//써 주어야 한다.
	//이때, 리턴 다음에는 값이나 변수명이 올 수 있다.
	//단, 변수의 타입이 리턴의 타입과 반드시 일치해야 한다.
	double methodB(double d1, double d2) {
		//System.out.print(d1+d2);
		//return 0;
		double hap = 0.0;
		hap = d1 + d2;
		return hap;
	}
	
	public static void main(String[] args) {
	//RAM영역에 Prameter1클래스를 로딩하기
		Parameter1 p1 = new Parameter1();//p1은 지변이다.
		//double hap = p1.methodA(10, 20);
		double hap2 = p1.methodB(10, 20);
		
		System.out.println(p1.methodB(10, 20));

	}

}
