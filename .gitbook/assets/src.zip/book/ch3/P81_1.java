package book.ch3;

public class P81_1 {

	public static void main(String[] args) {
		char ch = 65;
		System.out.println(ch);//A가 아스키코드에서 65에대응하므로 65로 출력된다.
		System.out.println('A');
		System.out.println("Hello".charAt(2));
		
	}

}
