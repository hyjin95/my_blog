package book.ch3;

public class P76 {

	public static void main(String[] args) {
		if(1==1) {
			System.out.println("네");
		}
		
		if(1!=1) {
			System.out.println("네");
		}
		
		else {
			System.out.println("1과1은 다르지 않다.=아니오");
		}

	}

}
