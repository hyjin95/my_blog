package book.ch3;

public class P77_1 {

	public static void main(String[] args) {
		int x = 1;
		int y = 2;
		if((++x<y)&(x>y--)) {//참일때
			System.out.println("참일때");			
		}
		else {//거짓말일때
			System.out.println("거짓말일때");			
		}
		//거짓말일때, x=2, y=1
		System.out.println("x="+x+", y="+y);		
		System.out.println("=======[[after]]=======");		
		//위의 결과가 밑에 조건문에 영향을 끼친다. 똑같은 조건으로 하려면 다시 초기화를 해야한다.
		x = 1;
		y = 2;
		if((++x<y)&&(x>y--)) {//참일때
			System.out.println("참일때");					
		}
		else {//거짓말일때
			System.out.println("거짓말일때");			
		}
		//초기화를 안했을 때, x=3, y=1, 첫 조건이 False라 두번째 조건은 진행하지 않는다.
		//거짓말일때, x=2, y=2
		System.out.println("x="+x+", y="+y);	
		
		x = 1;
		y = 2;
		if((++x<=y)|(x>y--)) {//참일때
			System.out.println("참일때");					
		}
		else {//거짓말일때
			System.out.println("거짓말일때");			
		}		
		//참일때, x=2, y=1
		System.out.println("x="+x+", y="+y);		 
		
		x = 1;
		y = 2;
		if((++x<=y)||(x>y--)) {//참일때
			System.out.println("참일때");					
		}
		else {//거짓말일때
			System.out.println("거짓말일때");			
		}		
		//참일때, x=2, y=2
		System.out.println("x="+x+", y="+y);	
	}

}
