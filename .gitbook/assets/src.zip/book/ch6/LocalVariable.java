package book.ch6;
/*
 * methodA에 선언된 지변을 외부 다른 메서드에서 유지 또는 사용할 수 있나요?
 * 1)static으로 선언된 변수를 사용하는것.(전역변수이용)
 * 2)전변에서 초기화하기. this.i = i;(전역변수이용)
 * 사용불가합니다. static이나 전역변수만 가능해요
 */

public class LocalVariable {
	int i = 1;
	//static int i = 2;//i가중복선언 되어있기때문에 이름을 다르게 해야한다.
	static int j = 2;//=싱글톤이다.
	
	void methodA() {
		int i;
		i=10;
		System.out.println(i);//10
		//static타입의 변수를 non-static영역에서 사용하는건 가능하다.
		System.out.println(j);//2
		
		this.i = i;//지역변수 i=10을 전역변수에 대입한다.
	}
	
	//static영역에서 non-static영역은 사용불가능하다.
	//인스턴스화하면 사용가능하다.
	public static void main(String[] args) {
		//메인메서드에서 지역변수 i는 접근이 불가하다.
		LocalVariable lv = new LocalVariable();
		System.out.println(lv.i);//인스턴스변수로 접근할수 있는 변수는 전역변수 뿐이다. = 1출력
		System.out.println(j);//2출력
		j = 50;
		lv.methodA();//j=2->50
		System.out.println(lv.i);//위 methodA에서 전역변수가 10으로 변했으므로 10출력
	}
}
