package book.ch6;

public class Company {
	
	private static Company instance = null;//new Company();
	
	private Company() {
		System.out.println("Company 디폴트 생성자 호출성공");
	}
	
	public static Company getInstance() {
		if(instance == null) {//인스턴스선언만 되어잇니?
			instance = new Company();//그럼 생성
		}			
		return instance;
	}
}
//private는 데이터를 get으로 걸러 받을때, 조건을 걸어야할때 사용