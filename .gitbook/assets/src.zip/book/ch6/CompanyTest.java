package book.ch6;

public class CompanyTest {

	public static void main(String[] args) {
		//Company cp = new Company(); //생성자가 private이므로 호출불가
		Company cp1 = Company.getInstance();//static이므로 : 타입.메서드();
		Company cp2 = Company.getInstance();//7번에서 인스턴스가 생성되었으므로 null이 아니다. 생성자를 호출하지 않는다.
		System.out.println(cp1 == cp2);//싱글톤이므로 주소가 두개지만 하나를 바라보고있다. true이다.
	}
}
