package book.ch4;

public class Test0805_Parameter_T {//메소드 조각내기
	
	public void methodA(int start, int end) {//범위를 수정지정할 수 잇다.
		
		for(int i=start; i<=end; i=i+1) {
		//for(int i=1; i<=100; i=i+1) {
			
			if((i%5==0)&&(i%7==0)) {
				System.out.println("fizzbuzz");
			}//end of if
			
			else if(i%5==0) {
				System.out.println("fizz");
			}//end of else if
			
			else if(i%7==0) {
					System.out.println("buzz");
				}//end of else if
			
			else {
				System.out.println(+i);
			}//end of else
		}//end of for
		//i=11
					
	}//end of methodA

	public static void main(String[] args) {
		
		Test0805_Parameter_T trt = new Test0805_Parameter_T();
				trt.methodA(5,10);		

	}//end of main

}//end of Test0805_method_T

