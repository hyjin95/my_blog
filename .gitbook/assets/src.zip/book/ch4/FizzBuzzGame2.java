package book.ch4;

public class FizzBuzzGame2 {//메소드 조각내기
	
	public void methodA() {
		
		for(int i=1; i<=100; i=i+1) {
			
			if((i%5==0)&&(i%7==0)) {
				System.out.println("fizzbuzz");
			}//end of if
			
			else if(i%5==0) {
				System.out.println("fizz");
			}//end of else if
			
			else if(i%7==0) {
					System.out.println("buzz");
				}//end of else if
			
			else {
				System.out.println(+i);
			}//end of else
		}//end of for
					
	}//end of methodA

	public static void main(String[] args) {
		
		FizzBuzzGame2 fbg = new FizzBuzzGame2();
				fbg.methodA();		

	}//end of main

}//end of Test0805_method_T

