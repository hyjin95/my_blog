package book.ch4;

public class Test_forif {
	
	boolean even(int i) {//짝수의 합을 구하는 메소드
		int evensum = 0;
		if(i%2==0){
			evensum = evensum+i;					
		}
		System.out.println("짝수의 합 = "+evensum);
		
		return ;
	}
	
	boolean	odd(int i) {
		
		int oddsum = 0;
		if(i%2!=0){
			oddsum = oddsum+i;					
		}
		System.out.println("홀수의 합 = "+oddsum);
		
		return ;
	}

	public static void main(String[] args) {		
		
		Test_forif tf = new Test_forif();
		
		for(int i=1; i<=10; i=i+1) {
			tf.even(i);
			tf.odd(i);
		}			
				
	}

}
