package book.ch4;

import javax.swing.JOptionPane;

public class Gugudan {
	
	int i;
	int j;
	
	void methodA(int input2) {//구구단 for 메소드			
	
		//for(i=input2;i<=input2;i++) {//단 증가 반복문
			
			System.out.println(input2+"단");
			
			for(j=1;j<10;j++) {//곱하기 증가 반복문				
				System.out.println(input2+"*"+j+"="+(input2*j));
			}//end of for			
		//}//end of for		
						
	}//end of methodA
	
	void methodB( ) {//구구단 while 메소드		
		i = 1;
		
		while(i<10) {
			
			System.out.println(i+"단");			
			j = 1;//j값 초기화
			
			while(j<10) {
				
				System.out.println(i+"*"+j+"="+(i*j));
				j++;				
			}//end of while			
			i++;
		}//end of while		
	}

	public static void main(String[] args) {
		
		 String input = JOptionPane.showInputDialog("몇단을 불러올까요?");
	     int input2 = Integer.parseInt(input);
	     
		 Gugudan ggd = new Gugudan();		 
		 ggd.methodA(input2);
		// ggd.methodB();
			

	}

}
