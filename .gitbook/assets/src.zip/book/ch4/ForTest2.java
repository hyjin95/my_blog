package book.ch4;

public class ForTest2 {

	public static void main(String[] args) {
		
		for(int i=0;i<5;i++) {
			if(i==1) break;
			System.out.println(i);//0은 if를 통과해서 출력되고 1은 break걸려서 for문을 빠져나가 10번으로 진행된다.
		}//end of for
		
		System.out.println("여기");
	}

}
