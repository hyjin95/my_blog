package book.ch4;

public class FizzBuzzGame4 {//메소드 조각내기
	
	public void methodA(int start, int end) {//범위를 수정지정할 수 잇다.
		
		int i=1;
		
		while(i<end) {
		
			if((i%5==0)&&(i%7==0)) {
				System.out.println("fizzbuzz");
			}//end of if
			
			else if(i%5==0) {
				System.out.println("fizz");
			}//end of else if
			
			else if(i%7==0) {
					System.out.println("buzz");
				}//end of else if
			
			else {
				System.out.println(+i);
			}//end of else
			i++;
		}//end of while
	}//end of methodA

	public static void main(String[] args) {
		
		FizzBuzzGame4 fbg = new FizzBuzzGame4();
		fbg.methodA(1,100);		

	}//end of main

}//end of Test0805_method_T
