package book.ch4;

public class ForTest {

	public static void main(String[] args) {
		//for(int i=1; i<=3; i=i+1) {
			//System.out.println(i);//1,2,3	
		int sum = 0;
		for(int i=1; i<=5; i= i+1) {
			if(i%2==0) {
				System.out.println(i);//2,4
				sum+=i;
			}			
		}
		System.out.println(sum);//6
	}

}
