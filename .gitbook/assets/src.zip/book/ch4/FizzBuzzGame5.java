package book.ch4;

public class FizzBuzzGame5 {//메소드 조각내기
	
	public void methodA(int start, int end) {//범위를 수정지정할 수 잇다.
		
		int i=1;
		
		while(i<end) {
			switch(i%35) {//큰 조건				
				case 0 : {//i를 35로 나눈 값이 0이니?
					System.out.println("fizzbuzz");
					break;
				}							
				case 5: case 10: case 15: case 20: case 25: case 30: {
						System.out.println("fizz");
						break;
					}//end of else if
				
				case 7: case 14: case 21: case 28: {
					System.out.println("buzz");
					break;
				}//end of else
				default: {
					System.out.println(i);
				}//end of default
			 }//end of switch
			i++;
		}//end of while
	}//end of methodA

	public static void main(String[] args) {
		
		FizzBuzzGame5 fbg = new FizzBuzzGame5();
		fbg.methodA(1,100);		

	}//end of main

}//end of Test0805_method_T
