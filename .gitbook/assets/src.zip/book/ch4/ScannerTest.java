package book.ch4;

import java.util.Scanner;

//모든 클래스는 Object클래스를 상속 받고 있다.
//그래서 Object에 정의된 메소드는 모두 내가 사용할 수 있는것이다.

public class ScannerTest {

	public static void main(String[] args) {
		
		int i = 0;
		//JoptionPane.showIputDialog역할 = scanner 역할
		//scanner 클래스는 util 밑에 있어서 import해야 사용가능한 예약어이다.
		Scanner scan = new Scanner(System.in);
		
		for(i=1;i<4;i++) {//i=1에서 i++되는데 i가 4미만이면 실행한다.=4번
			System.out.println("숫자를 입력하시오.");
			String num = scan.nextLine();
			System.out.println("num = "+num);
			//i=4
		}//end of for
		
		//System.out.println("i="+i);
		
		i = 1;//for문에서 사용된 i값 초기화
		while(i<4) { //4번 실행문을 반복한다.
			System.out.println("숫자를 입력하시오.");
			String num = scan.nextLine();
			System.out.println("num = "+num);
			i++;//이 단항증감식이 없다면 while문은 무한반복한다.
			//i=4
		}//end of while
		
	}

}
