package book.ch4;

import javax.swing.JOptionPane;

public class Test08052 {
	//피보나치 수열의 규칙을 찾아서 a1, a2, a3, ..., a10항까지 출력해주는 프로그램을 작성하시.(for, if 사)
	
	void methodA( ) {//for
		int i;
		int num1, num2, sum;
		num1 = 0;
		num2 = 1;
		sum = 1;
		
		for(i=0;i<10;i++) {			
			
			System.out.println("a"+(i+1)+"="+sum);//1,1,2,3,5
			sum = num1 + num2;//1,2,3,5
			num1 = num2;//num1=1,1,2,3
			num2 = sum;//num2=1,2,3,5
			
			
		}//end of for
	}//methodA

	void methodB() {
		int num[] = new int[3];
		num[0] = 1;
		num[1] = 1;
		System.out.println("a0="+num[0]);
		System.out.println("a1="+num[1]);
			
		for(int i=1;i<10;i++) {
			num[2]=num[1]+num[0];
			System.out.println("a"+(i+1)+"="+num[2]);
					
			for(int s=0;s<2;s++) {
				num[s]=num[s+1];
			}//end of for
					
		}//end of for				

	}//end of methodB
	
	void methodC() {
		
		int a = 0;
		int b = 0;
		int sum = 0;
		
		for(int i=1;i<11;i++) {
			if(i<=2) {
				a=1;
				b=1;
				sum=1;
				System.out.println("a"+i+"항은 "+sum);
			}//end of if
			
			else {
				sum=a+b;
				a=b;
				b=sum;
				System.out.println("a"+i+"항은 "+sum);				
			}//end of else
		}//end of for		
		
	}//end of methodC
	
	void methodT() {
		int a1=1, a2=1, a3=0;
		System.out.println(a1+""+ a2+"");
		for (int x=0;x<8;x++) {
			JOptionPane.showInputDialog(null,"before a1:"+a1+",a2:"+a2);
			a3=a1+a2;
			System.out.println(a3+"");
			a1 = a2;
			a2 = a3;
			JOptionPane.showInputDialog(null,"after a1:"+a1+",a2:"+a2);
		}
	}

	
	
	public static void main(String[] args) {
		Test08052 t08052 = new Test08052();
		
		//t08052.methodA();
		//t08052.methodB();
		//t08052.methodC();
		t08052.methodT();
		
	
		
	
		
	}

}