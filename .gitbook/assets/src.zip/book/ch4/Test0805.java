
package book.ch4;

public class Test0805 {

	public static void main(String[] args) {
		
		for(int i=1; i<=100; i=i+1) {
			
			if((i%5==0)&&(i%7==0)) {//범위가 큰 조건부터 나열한다. 작은조건이 먼저면 큰 조건이 이행되지 않을 수 있다.
				System.out.println("fizzbuzz");
			}//end of if
			
			else if(i%5==0) {
				System.out.println("fizz");
			}//end of else if
			
			else if(i%7==0) {
					System.out.println("buzz");
				}//end of else if
			
			else {
				System.out.println(+i);
			}//end of else
		}//end of for
		

	}

}
