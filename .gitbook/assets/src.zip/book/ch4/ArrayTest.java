package book.ch4;

public class ArrayTest {

	public static void main(String[] args) {
		int is[] = new int[3];//한번에방 3개 생성
		is[0] = 1;//0번 방 1으로 초기화
		is[1] = 2;//1번 방 2으로 초기화
		is[2] = 3;//3번 방 3으로 초기화
		
		double ds[] = new double[1];//방 1개생성
		
		for(int j=0;j<3;j++) {//j가 0이고 ++되는데 3이하면 is[j] 방의 값을 출력한다.
			System.out.println(is[j]);
			
		}//end of for
	}

}
