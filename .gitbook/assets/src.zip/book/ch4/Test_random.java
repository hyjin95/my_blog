package book.ch4;

import java.util.Random;//확인하기
import javax.swing.JOptionPane;//확인하기

public class Test_random {
	
	int random(int num) { //0~9사이의 임의의 숫자를 뽑아주는 메소드
		                
        Random tr = new Random();        
      
        num= tr.nextInt(10);         
        
        return 0;
	}
	
		
	public static void main(String[] args) {
		
		Test_random tr = new Test_random();
		
		int num1;
		String input;
		
		input = JOptionPane.showInputDialog("숫자를 맞춰보세요.");
	    int num2 = Integer.parseInt(input);
	    
	    num1 = tr.random(10);
	    
	    if(num2==num1){
        	System.out.println("정답입니다.");
        }
        else {
        	System.out.println("틀렸습니다.");
        }
        System.out.println(num1);
        System.out.println(num2);
        
       

	}

}
