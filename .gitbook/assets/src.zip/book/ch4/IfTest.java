package book.ch4;

import javax.swing.JOptionPane;
//모든 클래스는 Object로 부터 상속받아서 만들어진 것이다.
public class IfTest extends Object//상속(의존적), 부모객체
                                   {

	public static void main(String[] args) {
		//사용자로부터 점수를 입력 받고, 점수 변수를 선언하세요.
		//"점수를입력하세요."=객체
		//String보다 상위이다.
		String score = JOptionPane.showInputDialog("점수를 입력해주세요.");//요청=파라미터
		//score는 string타입이다.
		//범위가 int이므로 비교값도 int로 형변환 해야한다. 타입이 다르면 비교가 불가능하므로
		int score2 = Integer.parseInt(score);
		//너 90점 이상이니?
		//if()괄호 안에는 T나 F로 결과가 나오는 묻는값이 나와야한다. 단항연산자만은 있을 수 없다.
		//90은 상수
		if(score2>=90) {
			System.out.println("당신은 A학점을 받았습니다.");//응답			
		}
		//else if는 조건식이 있다. else는 조건식이 없이 그냥 나머지를 말한다.
		//위의 if에서 90점 이상은 참으로, 내려오지 않기때문에 굳이 &&조건을 쓰지 않아도 된다.
		else if(score2>=80) {			
			System.out.println("당신은 B학점을 받았습니다.");//응답
		}
		else if((score2>=70)&&(80>score2)) {			
			System.out.println("당신은 C학점을 받았습니다.");//응답
		}
		else if((score2>=60)&&(70>score2)) {			
			System.out.println("당신은 D학점을 받았습니다.");//응답
		}
		else if((score2>=50)&&(70>score2)) {			
			System.out.println("당신은 F학점을 받았습니다.");//응답
		}
		else {
			System.out.println("당신은 낙제하였습니다.");
		}
		//System.out.println(score2);
		

	}

}
