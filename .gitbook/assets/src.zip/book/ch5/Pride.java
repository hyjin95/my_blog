package book.ch5;

public class Pride extends Object {//모든 클래스의 아버지, toString()라는 메소드를 기본으로 갖고있다.
	int speed = 0;
	
	public String toString() {//클래스에 포함된 기본 메소드
		return "그녀의 자동차";
	}

	public static void main(String[] args) {
		Pride hercar = new Pride();
		System.out.println(hercar);//6-8번이 없으면 주소번지가 찍힌다.
		System.out.println(hercar.toString());//toString 생략가능
	}
}
