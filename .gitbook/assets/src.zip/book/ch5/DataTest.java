package book.ch5;

public class DataTest {//변수가 i로 정해져잇어서 for문 사용가능
	void guguDanPrint() {
		for(int i=2;i<10;i++) {
			for(int j=1;j<10;j++) {
				System.out.println(i+"*"+j+"="+(i*j));
			}//end of for
		}//end of for
	}//end of guguDanPrint

	public static void main(String[] args) {
		//변수 4개 배열로는 1개
		int deptno1 = 10;
		int deptno2 = 20;
		int deptno3 = 30;
		int deptno4 = 40;
		//부서 번호를 조회하는데 for문을 사용할 수 없다. for문안에 변수는 하나뿐이 못들어오므로.
		int deptnos[] = new int[4];
		deptnos[0] = 10;
		deptnos[1] = 20;
		deptnos[2] = 30;
		deptnos[3] = 40;
				
		DataTest dt = new DataTest();
		dt.guguDanPrint();
		
		for(int x=0;x<4;x++) {
			System.out.println(deptno1);
			System.out.println(deptno2);
			System.out.println(deptno3);
			System.out.println(deptno4);//이렇게 출력하려면 for문이 필요없다.
		}//end of for			
		for(int y=0;y<4;y++) {
			System.out.println(deptnos[y]);//이렇게 for을 사용한다.
		}//end of for
	}//end of main

}
