package book.ch5;

import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class Main1 extends JFrame implements ActionListener {
	//선언부 : 전변
	JButton    jbtn_south  = null;//class안에 선언
	JButton    jbtn_north  = null;
	JButton    jbtn_east   = null;
	JButton    jbtn_west   = null;
	JButton    jbtn_center = null;
	JTextField jtf_user    = null;//버튼대신 들어갈 jtf선언, 다른 클래스나 메서드에서도 재사용할수 있도록 class안에 전역번수로 선언한다.생성은 사용되는 이벤트performed안에서 한다.
	
	Container cont = this.getContentPane();

	//생성자 
	//리턴타입이 없다. 파라미터는 n개 가능하다. 메서드 오버로딩의 규칙을 준수한다. 전역변수의 초기화를 담당한다.
	public Main1( ) {//디폴트생성자, 초기화하는 역할
		jbtn_east   = new JButton("동쪽(버튼)");//생성자 안에 생성
		jbtn_south  = new JButton("남쪽(버튼)");
		jbtn_center = new JButton("중앙(버튼)");
		jbtn_west   = new JButton("서쪽(버튼)");
		jtf_user    = new JTextField();//사용할 곳에서 생성한다.
		//내안의 메서드, 전연변수는 인스턴스화없이 호출가능하다.
		initDisplay();//initDisplay가 버튼 위에 있으면 버튼이 null값을 가질 수도 있다.
	}
	
	//화면처리부
	public void initDisplay() {
		jbtn_south.addActionListener(this);
		jbtn_east.addActionListener(this);
		jbtn_west.addActionListener(this);
		jtf_user.addActionListener(this);
		this.add("East", jbtn_east);
		this.add("West", jbtn_west);
		this.add("Center", jbtn_center);
		this.add("South", jbtn_south);
		this.setSize(500, 400);
		this.setVisible(true);
	}

	//메인 메서드	
	public static void main(String[] args) {
		//여기에 인스턴스화를 하면 지역변수의 성격을 갖게되므로 외부에서 사용 불가하다.
		new Main1();//생성자 호출하기
	}

	//콜백메서드
	//시스템에서 자동으로 호출 됨 (감지하면 JVM이 호출)
	@Override
	public void actionPerformed(ActionEvent e) {
		Object obj = e.getSource();//이벤트감지
		String msg = jtf_user.getText();//사용자가 입력한 문자열 읽어오기, jtf_user가 사용되기 전에 생성되어야한다.
		if(obj==jtf_user) {//사용자가 입력한 문자열을 이벤트 감지했을때
			if("북쪽".equals(msg)) {
				jbtn_north = new JButton("북쪽(버튼)");//이벤트가 일어난 후에 생성하므로 여기에 생성
				cont.add("North",jbtn_north);
				cont.revalidate();
			}//end of if											
			else {
				JOptionPane.showMessageDialog(this, "북쪽을 입력해 주세요.");
				jtf_user.setText("");
				return;
			}
		}//end of if
		else if(obj==jbtn_west) {
			if(jbtn_center!=null) {
			cont.remove(jbtn_center);
			}
			if(jbtn_west!=null) {
			cont.remove(jbtn_west);
			}
			if(jbtn_north!=null) {
				cont.remove(jbtn_north);
			}
			if(jbtn_east!=null) {
			cont.remove(jbtn_east);
			}
			if(jtf_user!=null) {
				cont.remove(jtf_user);
			}
			cont.revalidate();			
		}
		else if(obj==jbtn_east) {
			jbtn_east.setText("메뉴");
		}
		
		else if(obj==jbtn_south) {
			System.out.println("남쪽버튼 클릭");
			
			//java에서는 remove했다고 삭제되는것이 아니라 Candidate상태로 전환한다.=쓰레기값, 곧 내가 청소할 거라고 찜해놓는것.
			cont.remove(jbtn_south);//버튼을 전환할거야
			System.out.println(jbtn_south);//주소번지 출력됨
			jbtn_south = null;//초기화 : JVM이 기억하고 있는 주소번지를 지워줌 =Candidate상태로 할거다라는 의미
			//끼어들 위치를 설정해야한다.
			
			//initDisplay에서 이벤트 핸들러와 연결하지 않고
			//이벤트가 발동해야 인스턴스화를 완성한다. 
			//jtf_user = new JTextField();//남쪽버튼을 누르면 생성된다.
			//jtf.actionLitener(this);
			cont.add("South",jtf_user);//새로 붙이기
			cont.revalidate(); 				
		}//end of if	
		
	}//end of actionPerformed
}//end of class

//main -> 생성자 호출 -> 버튼생성, 화면호출 -> 클리시 event만들기
//현재 선언과 생성을 따로 분리하는것은 따로 차이가 없다. 향후에 화면구현, 또는 이벤트 처리시 따로 분리하는 부분이 필요해서 연습한다.
//다만 생성자 안에서 initDisplay를 호출함에 따라 initDisplay를 먼저 호출하면 해당 버튼을 보지 못할 수도 있다.
//1.선언부, 생성자, 화면처리부, 메인메서드 구분
//2.디폴트 생성자 생성
//3.main메서드에서 생성자 호출
//4.생성자에서 화면호출
//5.화면처리 메서드 설정
//6.south버튼 붙이기 : 선언은 class안에 이름과 생성은 생성자안에 구현은 화면생성메서드안에
//7.south버튼을 누르면 그 버튼을 JTextField로 바꾸기 : 기존 버튼을 지워야 한다. : Container 클래스 안의 remove메서드 이용!
//API : Container(JFrame이 붙어있는 캔버스) : Container cont = this.getContentPane();
//화면에서 버튼 지우기 : cont.remove(삭제할 화면정보)
//버튼을 JTextFeild로 갱신하기 : cont.revalidate()
//화면처리부에 addactionListener, 클래스에 implement ActionListener 추가, 오버라이드 설정
//8.입력창에 :"북쪽"+enter하면 북쪽에 버튼 나타내기
//jtf를 이벤트 핸들러와 매칭해준다. : jtf_user.addActionListener(this);
//사용자가 입력한 문자열을 가져온다. : jtf_user.getText();
//actionPerformed에 jtf이벤트가 감지되었을 때 입력된 문자열 값이 "북쪽"이면 버튼을 생성, 화면 North영역에 붙이기
//다른 컴퍼넌트가 없던 자리에 붙이는 것이므로 remove는 사용하지 않는다.
//이벤트 처리에서 생성한 버튼을 화면에 넣고 화면을 갱신한다.
//9.동쪽, 서쪽 입력시 버튼만들고 동쪽버튼 클릭시 "메뉴"로 텍스트 변경
//10.서쪽 클릭시 초기화