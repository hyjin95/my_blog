package book.ch5;

public class DeptVOSimulation {

	public static void main(String[] args) {
		//부서번호 10, 부서이름 accounting, 부서위치 newyork
		DeptVO dVO = new DeptVO();//한번에 하나의 로우를 담는다.
		DeptVO[] dVOS = new DeptVO[3];
		
		dVO.setDeptno(10);
		dVO.setDname("Accounting");
		dVO.setLoc("NEW YORK");
		System.out.println(dVO.getDeptno());
		System.out.println(dVO.getDname());
		System.out.println(dVO.getLoc());
		
		dVOS[0] =dVO;//풍선을 넣어둠
		
		dVO = new DeptVO();//변수이름은 같아도 주소는 다르다. 복사, 이사 : 한번에 하나의 로우를 담는다.
		dVO.setDeptno(20);
		dVO.setDname("RESEARCH");		
		dVO.setLoc("DALLAS");
		System.out.println("===============");
		System.out.println(dVO.getDeptno());
		System.out.println(dVO.getDname());
		System.out.println(dVO.getLoc());
		
		dVOS[1] =dVO;//20이 담긴다

		dVO = new DeptVO();//주소 복사, 이사 : 한번에 하나의 로우를 담는다.
		dVO.setDeptno(30);
		dVO.setDname("SALES");		
		dVO.setLoc("CHICAGO");
		System.out.println("===============");
		System.out.println(dVO.getDeptno());
		System.out.println(dVO.getDname());
		System.out.println(dVO.getLoc());
		System.out.println("===============");

		dVOS[2] =dVO;//30이 담긴다.
		
		for(int i=0;i<dVOS.length;i++) {//length가 있으면 원소의 갯수를 적어준다. = 세방에 원소가 3개, 3
			DeptVO rVO =dVOS[i];
			System.out.println(rVO.getDeptno()+", "+rVO.getDname()+", "+rVO.getLoc());
		}
	}//위의 부서번호,이름, 위치는 고정 값 
	//값이 수정되었을때 죽은 값이 나오는 오류가 날 수 있어서 이런방법을 선호하지 않는다.
	//부서가 여러 개인 경우에 이런방법은 쓸 수 없다.

}//Eclipse에서 debug모드로 변화를 확인할 수 있다.
