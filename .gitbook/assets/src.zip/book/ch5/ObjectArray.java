package book.ch5;

import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;

public class ObjectArray extends JFrame{
	JButton jbtns[] = new JButton[10];//JButton은 string 타입이다. >19번
	int     nums[]  = {0,1,2,3,4,5,6,7,8,9};
	
	public ObjectArray() {
		initDisplay();
	}
	
	public void initDisplay() {
		this.setLayout(new GridLayout(1,10));
		for(int i=0;i<jbtns.length;i++) {
			jbtns[i]= new JButton(nums[i]+"");//버튼만들기 반복 / =객체배열 / 괄호안에 String 타입이 와야하기때문에 ""를 더한다.
			this.add(jbtns[i]);//담는 부분도 반복
		}
		this.setSize(600,200);
		this.setVisible(true);
	}

	public static void main(String[] args) {
		new ObjectArray();

	}

}
