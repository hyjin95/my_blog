package book.ch5;

public class StringTest {

	public static void main(String[] args) {
		String msg = "hello";
		msg.replace("e", "o");//replace메소드가 e를 o로바꾼다.
		System.out.println(msg);//=연산자가 없어서 String은 원본을 유지한다.
		msg = msg.replace("e", "o");//replace 메소드를 msg에 대입시킨다.
		System.out.println(msg);
		
		StringBuilder sb = new StringBuilder("hello");//StringBuilder 타입은 뒤어 이어붙일 수 있다.
		sb.append(" world!!!");//append메소드는 붙여주는 메소드
		System.out.println(sb.toString());
		
		String str = "hello";//String은 덩어리개념이다.원본1
		str = str+" world";//덩어리째 hello world로 바뀐다.원본2
		str +=" java";//덩어리째 hello world java로 바뀐다.원본3 = 공간낭비
		System.out.println(str);

	}

}
