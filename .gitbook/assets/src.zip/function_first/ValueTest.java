package function_first;

public class ValueTest {
	private int i;
	static  int j;
	
	public ValueTest() {
		this.i = i + 10;
		System.out.println(i);
	}
	
	public ValueTest(int i) {
		i = i - 50;
		System.out.println(i);
	}
	
	public static void main(String[] args) {
		ValueTest vt = new ValueTest();	
		new ValueTest(5);
	}
}
