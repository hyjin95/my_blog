package function_first;

import book.ch2.Sonata;

public class FunctionExam1 {
	//선언부
	
	//생성자 : 리턴타입이 없다. 생성자와 메서드의 차이점
	public FunctionExam1() {
		
	}
	
	void methodA() {//lev1
		//이 안에서 결정된 값을 외부에서는 사용할수 없다. 리턴타입이 void라 반환값이 없기때문.
		//다른 메서드에서도 사용하고싶다면 전역변수에 담아준다.
		//메서드는 스택에 담기므로 사라진다. = 유지불가
	}
	
	int methodB() {//lev2 리턴타입이 int인 메서드	
		//다른 함수에서나 클래스(인스턴스화)에서 호출된 결과를 재사용할 수 있다.
		return 10;//이 함수의 반환값을 재사용할 수 있다.
	}
	
	Sonata methodC() {//lev3 리턴타입이 클래스, Sonata가 public이라면 다른패키지의 것이지만 import하면 접근가능하다.
		return new Sonata();
	}
	
	//메서드 오버로딩 : 무조건 파라미터의 갯수가 다르거나 타입이 달라야한다.
	private Sonata methodC(int i) {
		Sonata hercar = new Sonata();
		return hercar;
	}
	
	//메인 메서드 : 가능하면 메인메서드는 슬림하게
	public static void main(String[] args) {
		FunctionExam1 fe = new FunctionExam1();
		int i = fe.methodB();//i=10
		
		Sonata mycar = fe.methodC(i);//Sonata에 i가 0으로 전역변수로 선언,초기화 되어있다. = 0 이 출력될 것이다.
		mycar.speed = mycar.speed + 100;//speed=100
		System.out.println(mycar.speed);//speed는 패키지가 달라서 접근할수 없다. Sonata클래스에가서 전변speed에 public을 추가해준다면 사용할 수 있다.
		//메서드 C에서 생성된 소타나의 속도를 50으로 변경해주세요.
		//methodc()Sonata한대, methodC(int i)Sonata한대, = 서로다른 자동차
		Sonata himcar = fe.methodC();//주인없는 메서드
		himcar.speed = 50;
		System.out.println(himcar.speed);
	}
}
