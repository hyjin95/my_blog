package desigin.test;

import java.util.Vector;

public class VectorTest {

	public static void main(String[] args) {
		Vector v = new Vector();
		System.out.println(v.size());//0 add가 없어서 방이 생성되지 않았다.
		v.add("바나나");
		v.add("수박");
		v.add(1,"체리");
		
		for(Object obj:v) {
			String f = (String)obj;//캐스팅연산자로 타입을 맞춰준다.
			System.out.println(f);//바나나 체리 수박 : 끼워넣기
		}//end of for
	}//end of main
}//end of class
