package desigin.test;

public class MemberVO {
	private String nickName = null;
	private String gender   = null;
	
	public MemberVO() {}
	
	public MemberVO(String nickName, String gender) {//갯수만큼 다 써주어야함
		this.nickName = nickName;
		this.gender = gender;
	}
	
	public String getNickName() {
		return nickName;
	}
	public void setNickName(String nickName) {
		this.nickName = nickName;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
}
//우클릭 - Source - Generate getter and setter - select all - last member - finish