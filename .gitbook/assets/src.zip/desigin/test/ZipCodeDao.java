package desigin.test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;

import com.util.DBConnectionMgr;

public class ZipCodeDao {//조회하기
	DBConnectionMgr  dbmgr  = null;
	Connection con          = null;
	PreparedStatement pstmt = null;
	ResultSet rs            = null;
	
	public ZipCodeVO[] getZipCodeList(String dong) {//dong이 파라미터로 있어야 조회할 수 있다.
		ZipCodeVO zVOS[] = null;//조회할때마다 달라진다.= 지변, null=어느 동 우편번호를 조회할건지 모른다.
		dbmgr = DBConnectionMgr.getInstance();//static이 붙어있어서 바로 호출할 수 있다.
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT zipcode, address");//oracle에서 불러오는것이므로 oracle에 쓰인대로 불러온다 : 띄어쓰기 주의
		sql.append(" FROM   zipcode_t      ");//oracle 문자열은 ''로 한다.
		sql.append(" WHERE  dong LIKE ? ");//dong이 정해지지 않았으므로 ?처리, 테스트할때에는 임의 동을 넣자. 변수를 넣는방법2
		//sql.append(" WHERE  dong LIKE "+"'"+dong+"%'");//변수를 넣는방법1
		//sql.append("'"+dong+"%'");//변수를 넣는 방법1-1
		try {
			con = dbmgr.getConnection();
			pstmt = con.prepareStatement(sql.toString());
			pstmt.setNString(1,  dong+"%");//변수를 넣는방법2-1
			rs = pstmt.executeQuery();
			ZipCodeVO zVO = null;
			Vector    v   = new Vector();
			while(rs.next()) {//주소를 계속 새로 기억시킨다.
				zVO = new ZipCodeVO();
				zVO.setZipcode(rs.getInt("zipcode"));
				zVO.setAddress(rs.getString("address"));
				v.add(zVO);
			}
			zVOS = new ZipCodeVO[v.size()];//v.size = add한 갯수만큼
			v.copyInto(zVOS);//복사메서드
		}catch (Exception e) {//화면에 로딩화면이 들고있다 = 죽진않았다. 멈춘상태. -> 무언가 반복하고있다.
			
		}
		return zVOS;
	}//end of getZipCodList

}//end of class
//중요한 코드 : 28,29,31,32,33
