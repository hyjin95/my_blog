package desigin.test;

public class ZipCodeDaoSimulation {
	
	public static void main(String[] args) {
		ZipCodeDao zcDao = new ZipCodeDao();
		ZipCodeVO[] zVOS = zcDao.getZipCodeList("당산동");
		for(ZipCodeVO zVO:zVOS) {
			int zipcode = zVO.getZipcode();
			String address = zVO.getAddress();//불러올 정보의 타입을 맞춘다.
			System.out.println(zipcode+"-"+address);
		}
	}
}
