package desigin.test;

import javax.swing.JButton;
import javax.swing.JFrame;

//extends =상속, this(아빠꺼를 쓸수잇는 함수)를 쓸 수 있다. 
//JFrame(아빠)을 상속받는 InstanceTest(자식)클래스이다.=아들 안에 아빠
//예외 : static안에서는 this를 사용할 수 없다. : static=하나를 공유, 나눠쓰는것
//ex)Integer.=클래스와 같이 static은 클래스안에 있지만 Heap내부에서 따로 존재한다.공간이 많지않다. 적게사용하자!
public class InstanceTest extends JFrame {
	//선언부의 타입과 생성부의 타입이 다를 수 있다. 
	JButton jbtn_north = null;//사용되는 메서드에서 초기화 하지않으면 NullPointEception이 일어난다.
	JButton jbtn_south = null;
	
	public InstanceTest() {
		jbtn_north = new JButton("북쪽(버튼)");
	}//end of InstanceTest
	
	public InstanceTest(String label) {
		jbtn_south = new JButton("label");		
	}
	
	public void initDisplay() {
		if(jbtn_north!=null)//south버튼이 add되어있지않으므로 비어있다.
			this.add("North", jbtn_north);
		this.setTitle("인스턴스화 분리");
		this.setSize(400, 500);//내거 아님, 아빠JFrame이 갖고있는 메서드
		this.setVisible(true);
	}//end of initDisplay

	public static void main(String[] args) {
		InstanceTest it = new InstanceTest("남쪽");
		it.initDisplay();
		//JFrame jf = new InstanceTest();//왼쪽항에 큰 타입, 오른쪽 항에 작은 타입이 와야하므로 성립하지 않는다.
		//jf.initDisplay(); initDisplay가 아들한테 있지 아빠한테 없기때문에 호출불가 오류
		//아빠타입 변수로는 아들타입에 선언된 메서드를 호출 할 수 없다.
	}//end of main

}//end of class
