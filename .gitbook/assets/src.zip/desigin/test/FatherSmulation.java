package desigin.test;

class Father{
	
	public void methodA() {
		System.out.println("Father ---> methodA 호출성공");
	}//end of methodA
}//end of class

class Son extends Father {
	@Override
	public void methodA() {
		System.out.println("Son ---> methodA 호출성공");
	}
}
public class FatherSmulation {
	
	public static void main(String[] args) {
		Father fa = new Father();
		fa.methodA();
		Son    so = new Son();
		so.methodA();
		//두 개의 클래스 사이가 부자관계에 있을때에만 사용 가능하다.
		//출력결과는 자녀에 정의된 내용이 동일하게 적용된다.
		//이때 Father가 정의하고 있는 메서드는 은닉메서드가 된다.
		Father fa2 = new Son();
		fa2.methodA();
	}//end of main

}
