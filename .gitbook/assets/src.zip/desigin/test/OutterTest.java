package desigin.test;

class Outter {
	int i = 10;
	public Outter() {
		Inner in = new Inner();
		in.go();
	}
	
	public void come() {
		System.out.println("come 호출 성공");
	}
	//내부 클래스 라고 한다.
	//반드시 외부 클래스를 인스턴스화 해야만 접근이 가능하다.
	//외부 클래스의 멤버 변수를 사용할수 있다.
	class Inner {//클래스 안에 클래스쓰기
		public void go() {
			System.out.println("go 호출 성공 : "+i);
		}
		
	}//end of Inner class
}//end of Outter class

public class OutterTest {

	public static void main(String[] args) {
		Outter ot = new Outter();
		//Inner in = ot.new Inner();
		//in.go();
		ot.come();
	}

}
