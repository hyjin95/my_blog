package oracle.db;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnectionMgr {
	//공유 static(원본) 못바꾸게final "클래스이름"
	public static final String _DRIVER = "oracle.jdbc.driver.OracleDriver";//ClassNotFoundException오류가 날 수 있다.
	//물리적인 주소가 있어야한다. 
	public static final String _URL = "jdbc:oracle:thin:@192.168.0.187:1521:orcl11";//thin:ip주소:대문:식별자
	
	public static String _USER = "scott";//final이 없다 보안때문에 주기적으로 변경해야한다.
	public static String _PW   = "tiger";
	//클래스 두개를 사용하려는 것으로 다른 클래스에서도 사용해야 하므로 전역변수로 선언해야 한다.
    public Connection con = null;
	//물리적으로 떨어져 있는 오라클 서버와 연결 통로 만들기
	public Connection getConnection() {//Connection import, 참조형이다, 연결
		try {//예외처리를 했다. 실행시에 에러발생할 가능성이있는 코드는 try-catch로 예외처리한다.
			Class.forName(_DRIVER);///////////////////////////////드라이버 클래스 이름을 찾는 호출
			con = DriverManager.getConnection(_URL, _USER, _PW);//연결 호출 == 인스턴스화
		} catch (ClassNotFoundException ce) {/////////////////////클래스 이름을 찾을수 없는 오류 예외처리
			System.out.println("드라이버 클래스를 찾을 수 없습니다.");
		} catch (Exception e) {///////////////////////////////////con, 연결 오류에 대한 예외처리
			System.out.println("연결 실패 "+e.toString());
		}
		//return null;//NullPointerException 오류
		return con;//return 반환타입이 인터페이스이다.
	}
	public static void main(String args[]) {
		DBConnectionMgr dbMgr = new DBConnectionMgr();
		dbMgr.con = dbMgr.getConnection();
		System.out.println("con ===> "+dbMgr.con);
	}//end of main
}//end of class
