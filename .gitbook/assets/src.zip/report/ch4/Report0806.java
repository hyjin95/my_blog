package report.ch4;

import java.util.Random;

public class Report0806 {
	
	void methodA( ) {
		
		Random r = new Random();
		
		int i;
		int result;
		int minus=0;
		int plus=0;
		
		for(i=1;i<=10;i++) {
		
			int num = r.nextInt(10);
			
			if((result = r.nextInt(2))==1) {
				num = num*-1;
				System.out.println(num);
				minus = minus+num;
			}
			
			else {
				System.out.println(num);
				plus = plus+num;
			}								
			
		}//end of for	
		
		System.out.println("음수의 합 = "+minus);
		System.out.println("양수의 합 = "+plus);
		
	}

	public static void main(String[] args) {
		Report0806 r0806 = new Report0806();
		r0806.methodA();		
		

	}

}
