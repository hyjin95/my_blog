package report.ch4;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Random;

public class RandomGame {

	public static void main(String[] args)
	throws IOException//예외처리를 직접하지 않고 미룬다.
	
	{		
		Random r = new Random();
		int dap = r.nextInt(10);//dap=채권한 숫자
		
		BufferedReader br = 
				new BufferedReader(
						new InputStreamReader(System.in));
		System.out.println("0부터 9사이의 숫자를 하나 입력하세요.");//입력되는 숫자는 문자타입
		String str = null;//값이 정해지지 않았다.
		
		while((str=br.readLine())!=null) {//뭐든 입력만 하면 파일이 끝날때 까지 읽는다.
			System.out.println("사용자가 입력한 값 = "+str);
			
			if(Integer.parseInt(str)==dap) {//입력과 채권 수가 같으면 종료
				System.out.println("정답입니다.");
				break;
			}//end of if 
			
			else if(Integer.parseInt(str) > dap) {
				System.out.println("Down");
			}//end of else if
			
			else if(Integer.parseInt(str) < dap) {
				System.out.println("UP");
			}//end of else if
			
			if("q".equals(str)) {
				System.out.println("프로그램을 종료합니다.");
				break;
			}//end of if
		}//end of while
		
	}

}

//boolean isStop = false;
//int i = 1;
//while(!isStop) {//true입력시 오류
//	int num = r.nextInt(10);//0-9랜덤뽑기
//	System.out.println(num);
//	
//	if(i>5) {
//		break;
//	}//end of if
//	i++;
//}//end of while
