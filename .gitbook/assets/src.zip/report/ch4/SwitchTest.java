package report.ch4;

public class SwitchTest {
	
	public int others(int x) {
		//switch(x%35) 가능:35로 나눈 '값'
		switch(x) {//x=5이므로 case4에서 시작
		   case 6 : x--;
		   case 5 : x--;//5 -> 4
		   case 4 : x--;//4 -> 3
		   case 3 : x--;//3 -> 2
		   break;// switch 탈출
		   default : x--;
		   break;
		}//end of switch
		return x;
	}
	//메소드 앞에 static이 있으면 인스턴스화가 필요없다.
	//static이 없는 메소드를 호출 할 때에는 무조건 인스턴스화 해야한다.
	//파라미터 자리는 지역변수 자리이다. = 초기화 필수
	//선언만 하는것은 문제되지 않지만, 사용할때 문제가 된다.
	public static int switchit(int x) {//파라미터의  x값은 호출할때 결정된다.
		int j = 1;
		switch(x) {//x=5이므로 case 5에서 시작
		   case 1 : j++;
		   case 2 : j++;
		   case 3 : j++;
		   case 4 : j++;
		   case 5 : j++;//1 -> 2
		   default : j++;//2 -> 3 default=else
		}//end of switch
		return j+x;//3+5 = 8
	}
	
	public static void main(String[] args) {
		int x = 5;
		SwitchTest st = new SwitchTest();
		System.out.println("x = " +st.others(x));
	
		//static메소드인 메인안에서 static으로 선언된 switch메소드를 호출시, 클래스이름.메소드이름으로 호출한다.
		int out = SwitchTest.switchit(x);
		System.out.println("j+x = "+out);	
	}

}
