package report.ch4;

public class SwitchTest2 {
	String msg;
	public void methodA( ) {
		int i = 0;
		boolean isOk = false;
		while(!isOk) {
			String msg = "오늘 스터디 할까?";
			switch(i) {
			case 0: {
				String msg = "";//위에서 변수타입을 선언했으므로 타입이 또 있으면 오류가 생긴다. 		
			}break;
		    default:
			break;
     	  }//end of switch
		}//end of while
	}//end of methodA

	public static void main(String[] args) {
		int j = 0;
		for(int i=0;i<3;i++) {			
		}
		for(j=0;j<3;j++) {			
		}		
		System.out.println(i);//for문 안에서 i를 선언한 경우 for문밖에서 인식할 수 없다.
		System.out.println(j);
	}//end of main
}
