package game.baseball;

public class Test1 {
	int g_i;
	
	void methodA( ) {
		int a_i;
		a_i = 1;
		g_i++;
	}
	
	void methodB() {
		g_i = g_i+5;	
	}
	public static void main(String[] args) {
		Test1 t1 = new Test1();
		
		t1.methodA();
		System.out.println(t1.g_i);//1
		t1.methodB();
		System.out.println(t1.g_i);//6
		
		Test1 t2 = new Test1();
		t2.methodA();
		System.out.println(t2.g_i);//1
	}

}
