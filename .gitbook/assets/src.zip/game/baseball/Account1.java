package game.baseball;
/*
 * for문 안에서 break문을 만나면 for문을 빠져나가는 것이고
 * if문 안에서 return을 만나면 메소드를 빠져나간다.
 */

public class Account1 {

	public String account(String user) {
		//문자열의 길이를 체크하고 싶을 때
		//if문 안에 return이오면 메소드를 탈출한다.(return을 반환하고 메소드를 더이상 진행하지 않는다.)
		if (user.length()!=3) {
			return "세자리 숫자를 입력하시오.";
		}//end of if		
		int temp = Integer.parseInt(user);
		int my[] = new int[3];
		my[0] = temp/100;
		my[1] = (temp%100)/10;
		my[2] = temp%10;
		 
		for(int x=0;x<3;x++) {
			System.out.println(my[x]+"");
		}//end of for
		return "0스트라이크 2볼";
	}//end of account 
	
	public static void main(String[] arg) {
		Account1 al = new Account1();
		String result = al.account("25687");
		System.out.println("1.256:"+result);
	}
	
}
