package game.baseball;

import javax.swing.JOptionPane;

public class BBGameSimulation {

	public static void main(String[] args) {
		
		BaseBallGame bbg = new BaseBallGame();//불러올 클래스 인스턴스화		
		
		bbg.ranCom();
		System.out.println(bbg.com[0]+""+bbg.com[1]+""+bbg.com[2]);
		System.out.println("====열번 돌려보기====");
		//10번 돌려보기
		/*for(int i=0;i<10;i++) {
			bbg.ranCom();
			System.out.println(bbg.com[0]+""+bbg.com[1]+""+bbg.com[2]);
			
		}//end of for*/
		String user = JOptionPane.showInputDialog("세자리 숫자를 입력하시오.");
		String result = bbg.account(user);
		System.out.println("result = "+result);
	}//end of main

}
