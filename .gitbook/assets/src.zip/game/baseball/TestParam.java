package game.baseball;

class Param{
	int ival;
}

public class TestParam {
	void effectParam(Param p) {
		p = new Param();//주소 재정의 : 주소변경 abcd ->1234
		p.ival = 500;//1234p.ival=500;
		System.out.println("sub ival = "+p.ival);
	}

	public static void main(String[] args) {
		//내 안에 있는 메소드 이지만 static영역에서 호출하려면 인스턴스화 필수
		TestParam tp = new TestParam();
		//effectParam메소드를 호출 할 예정인데 메소드에 파라미터 Param타입이 들어있음.
		//그래서 인스턴스화 함. 인스턴스화 하지 않으면 가리키는 객체는 없이 타입만 있는 것이다.
		Param p = new Param();//abcd p
		//main메소드 안에서 선언했기에 지변의 성격을 갖는다.
		//그 클래스에 선언된 ival변수는 처음에 0이였으나 아래 초기화를 통해 100이 담겼다.
		p.ival = 100;//abcd p
		//내 안의 메소드를 호출 하는데 이때 18번에 정의한 주소번지를 넘김
		tp.effectParam(p);//값이 아닌 참조에 의한 호출이다. abcd주소를 주엇지만 1234로 이사를감
		System.out.println("main ival = "+p.ival);//abcd p 출력
 
	}

}
