package game.baseball;

import javax.swing.JFrame;//dlc개념, MVC패턴이 적용된 패키지
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

import java.lang.String;//기본 패키지에 있어서 import하지 않아도 사용할 수 있다.

public class MenuBarTest {

	int width;//JFrame의 가로길이 전역변수 선언
	int height;//JFrame의 세로길이 전역변수 선언
	//JMenuBar클래스를 활용하여 JFrame에 메뉴바를 구성 할 수 있다.
	JMenuBar jmb = new JMenuBar();
	//JMenuBar에 추가할 JMenu를 생성한다.
	JMenu jm_file = new JMenu("File");
	//JMenu에 들어갈 하위메뉴 아이템 생성(New, Open ,나가기)
	JMenuItem jmi_new   = new JMenuItem("New");
	JMenuItem jmi_open  = new JMenuItem("Open");
	JMenuItem jmi_exit  = new JMenuItem("나가기");
	JMenu     jm_edit   = new JMenu("Edit");
	JMenuItem jmi_copy  = new JMenuItem("Copy");
	JMenuItem jmi_cut   = new JMenuItem("Cut");
	JMenuItem jmi_paste = new JMenuItem("붙여넣기");

		//화면을 그리는 메소드
	//재사용을 위한 첫걸음 : 메소드 중심의 코딩을 전개하는 것.
	public void initDisplay() {//화면
		System.out.println("initDisplay 호출 성공");
		////////메뉴 바 구성하기 시작////////
		jm_file.add(jmi_new);		
		jm_file.add(jmi_open);		
		jm_file.add(jmi_exit);		
		jm_edit.add(jmi_copy);		
		jm_edit.add(jmi_cut);		
		jm_edit.add(jmi_paste);		
		jm_file.setMnemonic('f');
		jm_edit.setMnemonic('e');
		jmb.add(jm_file);
		jmb.add(jm_edit);
		////////메뉴 바 구성하기 끝////////
		//JAVA API를 활용하여 윈도우 운영체제에서 화면을 열어주는 클래스
		//java.lang패키지를 제외한 모든 패키지는 반드시 import를 해주어야 해당 클래스를 JDK가 찾을 수 있다.
		JFrame jf = new JFrame();
		//이 메소드는 non-static영역이다.
		
		boolean isView;//setVisible(true)해도 되는데 변수 활용하기 위함
		isView = true;
		int width  = 600;//지역변수
		this.height= 400;//this.이름 ==전역변수
		this.width = 300;//전역변수, this생략가능
	
		jf.setJMenuBar(jmb);
		jf.setSize(width, height);
		jf.setVisible(isView);//setVisible("boolean"), true:음악을 듣고 있을때, false:듣는 중인데 전화가 온다.
	}//end of initDisplay
	
	public static void main(String[] args) {
		MenuBarTest mbt = new MenuBarTest(); //static에서 non-static 메소드를 호출하기위해 인스턴스화
		mbt.initDisplay();
		
	}//end of main

}
